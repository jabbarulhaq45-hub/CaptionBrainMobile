package com.captionbrain.mobile;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

public class CapCutAccessibilityService extends AccessibilityService {
    private static CapCutAccessibilityService instance;
    private volatile boolean paused = false;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { instance = null; super.onDestroy(); }

    public static boolean isEnabled(Context context) {
        String expected = new ComponentName(context, CapCutAccessibilityService.class).flattenToString();
        String enabled = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) if (expected.equalsIgnoreCase(splitter.next())) return true;
        return false;
    }

    public static boolean available() { return instance != null; }
    public static void pauseAutomation(boolean p) { if (instance != null) instance.paused = p; }

    /**
     * User-triggered baseline automation. This intentionally does not run invisibly.
     * It attempts to navigate CapCut's visible UI to its caption tools. CapCut labels
     * differ across versions/regions, so every step verifies an accessible label first.
     */
    public static void startCaptionAssist(StatusCallback cb) {
        if (instance == null) { cb.onStatus("Accessibility bridge is not enabled"); return; }
        instance.paused = false;
        instance.runBaseline(cb);
    }

    private void runBaseline(StatusCallback cb) {
        if (!isCapCutForeground()) {
            cb.onStatus("Open a CapCut project first, then press START AI");
            return;
        }
        cb.onStatus("CapCut detected • scanning visible editor controls");
        new android.os.Handler(getMainLooper()).post(() -> {
            if (paused) return;
            boolean textClicked = clickAny(new String[]{"Text", "text"});
            if (!textClicked) {
                cb.onStatus("Project detected • Text control not exposed to Accessibility on this CapCut screen");
                return;
            }
            cb.onStatus("Text panel opened • looking for caption controls");
            new android.os.Handler(getMainLooper()).postDelayed(() -> {
                if (paused) return;
                boolean captions = clickAny(new String[]{"Auto captions", "Auto Captions", "Captions", "Auto caption"});
                if (captions) cb.onStatus("Caption panel opened • ready for style analysis stage");
                else cb.onStatus("Text panel opened • caption label differs in this CapCut version");
            }, 700);
        });
    }

    private boolean isCapCutForeground() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null) return false;
        String p = root.getPackageName().toString();
        return p.equals("com.lemon.lvoverseas") || p.equals("com.lemon.lv");
    }

    private boolean clickAny(String[] candidates) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        for (String text : candidates) {
            List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(text);
            if (list == null) continue;
            for (AccessibilityNodeInfo n : list) {
                if (clickNodeOrParent(n)) return true;
            }
        }
        return false;
    }

    private boolean clickNodeOrParent(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i=0; i<4 && cur != null; i++) {
            if (cur.isClickable() && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            cur = cur.getParent();
        }
        return false;
    }

    public interface StatusCallback { void onStatus(String status); }
}
