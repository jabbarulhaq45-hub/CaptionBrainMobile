package com.captionbrain.mobile;

/**
 * Deterministic first-pass style selector distilled from the five user-supplied
 * reference videos. It is deliberately separate from CapCut UI automation so a
 * future vision/transcription model can feed it scene observations.
 */
public final class ReferenceCaptionBrain {
    public enum Style {
        BOLD_WHITE_SHADOW,
        SMALL_YELLOW_CINEMATIC,
        BLACK_SERIF_MINIMAL,
        RED_BOLD_MINIMAL,
        WHITE_SERIF_EMOTIONAL,
        OVERSIZED_WHITE_IMPACT
    }

    public static Decision decide(Scene s) {
        Style style;
        if (s.cleanLightBackground && s.emphasis >= 0.80f) style = Style.RED_BOLD_MINIMAL;
        else if (s.cleanLightBackground && s.reflective) style = Style.BLACK_SERIF_MINIMAL;
        else if (s.emphasis >= 0.90f && s.words <= 4) style = Style.OVERSIZED_WHITE_IMPACT;
        else if (s.reflective) style = Style.WHITE_SERIF_EMOTIONAL;
        else if (s.emphasis < 0.55f) style = Style.SMALL_YELLOW_CINEMATIC;
        else style = Style.BOLD_WHITE_SHADOW;

        String position;
        if (s.faceLeft) position = "mid-right";
        else if (s.faceRight) position = "mid-left";
        else if (s.busyLowerThird) position = "top-center";
        else position = "lower-center";

        String motion = s.emphasis >= .85f ? "pop-scale-105" : (s.reflective ? "soft-fade" : "none");
        return new Decision(style, position, motion);
    }

    public static final class Scene {
        public boolean cleanLightBackground;
        public boolean reflective;
        public boolean faceLeft;
        public boolean faceRight;
        public boolean busyLowerThird;
        public float emphasis;
        public int words;
    }

    public static final class Decision {
        public final Style style;
        public final String position;
        public final String motion;
        public Decision(Style style, String position, String motion) {
            this.style = style; this.position = position; this.motion = motion;
        }
    }
}
