package com.captionbrain.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private TextView bubble;
    private LinearLayout panel;
    private WindowManager.LayoutParams bubbleParams, panelParams;
    private TextView status;

    @Override public void onCreate() {
        super.onCreate();
        startAsForeground();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        createBubble();
    }

    private void startAsForeground() {
        String id = "captionbrain_overlay";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(id, "CaptionBrain bubble", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, id) : new Notification.Builder(this);
        b.setContentTitle("CaptionBrain ready")
                .setContentText("Tap the CB bubble inside CapCut")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentIntent(pi)
                .setOngoing(true);
        startForeground(77, b.build());
    }

    private void createBubble() {
        bubble = new TextView(this);
        bubble.setText("CB");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(16);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.rgb(20,20,20));
        bg.setStroke(dp(2), Color.WHITE);
        bubble.setBackground(bg);
        bubble.setElevation(dp(10));

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        bubbleParams = new WindowManager.LayoutParams(dp(58), dp(58), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = getResources().getDisplayMetrics().widthPixels - dp(74);
        bubbleParams.y = dp(180);
        wm.addView(bubble, bubbleParams);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy; float dx, dy; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sx = bubbleParams.x; sy = bubbleParams.y; dx = e.getRawX(); dy = e.getRawY(); moved = false; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    int nx = sx + (int)(e.getRawX()-dx), ny = sy + (int)(e.getRawY()-dy);
                    if (Math.abs(nx-sx)>8 || Math.abs(ny-sy)>8) moved = true;
                    bubbleParams.x = nx; bubbleParams.y = ny; wm.updateViewLayout(bubble, bubbleParams); hidePanel(); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    if (!moved) togglePanel(); else snapToSide();
                    return true;
                }
                return false;
            }
        });
    }

    private void snapToSide() {
        int width = getResources().getDisplayMetrics().widthPixels;
        bubbleParams.x = bubbleParams.x + dp(29) < width/2 ? dp(8) : width-dp(66);
        wm.updateViewLayout(bubble, bubbleParams);
    }

    private void togglePanel() {
        if (panel != null) { hidePanel(); return; }
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(15), dp(16), dp(15));
        panel.setBackground(roundRect(Color.WHITE, 20));
        panel.setElevation(dp(14));
        TextView head = label("CaptionBrain AI", 17, true, Color.BLACK);
        panel.addView(head);
        status = label("Ready • open your CapCut project", 12, false, Color.DKGRAY);
        status.setPadding(0, dp(5), 0, dp(9));
        panel.addView(status);

        Button start = miniButton("START AI");
        start.setOnClickListener(v -> {
            status.setText("Starting…");
            CapCutAccessibilityService.startCaptionAssist(s -> status.post(() -> status.setText(s)));
        });
        panel.addView(start, rowParams());
        Button pause = miniButton("PAUSE");
        pause.setOnClickListener(v -> { CapCutAccessibilityService.pauseAutomation(true); status.setText("Paused"); });
        panel.addView(pause, rowParams());
        Button stop = miniButton("STOP & CLOSE");
        stop.setOnClickListener(v -> stopSelf());
        panel.addView(stop, rowParams());

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        panelParams = new WindowManager.LayoutParams(dp(260), WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        int screenW = getResources().getDisplayMetrics().widthPixels;
        panelParams.x = bubbleParams.x > screenW/2 ? Math.max(dp(8), bubbleParams.x-dp(270)) : bubbleParams.x + dp(66);
        panelParams.y = Math.max(dp(40), bubbleParams.y-dp(12));
        wm.addView(panel, panelParams);
    }

    private void hidePanel() {
        if (panel != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
    }

    @Override public void onDestroy() {
        hidePanel();
        if (bubble != null) try { wm.removeView(bubble); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private Button miniButton(String t) {
        Button b = new Button(this);
        b.setText(t); b.setTextSize(13); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.WHITE); b.setBackground(roundRect(Color.rgb(20,20,20), 14));
        return b;
    }
    private LinearLayout.LayoutParams rowParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(45)); p.setMargins(0, dp(7), 0, 0); return p;
    }
    private TextView label(String s, int sp, boolean bold, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private GradientDrawable roundRect(int c, int r) { GradientDrawable d = new GradientDrawable(); d.setColor(c); d.setCornerRadius(dp(r)); return d; }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
}
