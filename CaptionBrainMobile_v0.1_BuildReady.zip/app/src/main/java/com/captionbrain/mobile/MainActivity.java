package com.captionbrain.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        refreshStatus();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(247,247,247));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(28));
        scroll.addView(root);

        TextView brand = text("CaptionBrain", 30, true, Color.BLACK);
        root.addView(brand);
        TextView sub = text("AI caption assistant for CapCut", 15, false, Color.DKGRAY);
        sub.setPadding(0, dp(4), 0, dp(20));
        root.addView(sub);

        LinearLayout hero = card();
        TextView title = text("5-Video Reference Profile", 18, true, Color.WHITE);
        TextView body = text("Dynamic caption styling based on your five references: contextual placement, contrast, emphasis, font-family switching and motion cues.", 14, false, Color.rgb(235,235,235));
        hero.setBackground(roundRect(Color.rgb(20,20,20), 22));
        hero.addView(title);
        body.setPadding(0, dp(8), 0, 0);
        hero.addView(body);
        root.addView(hero, spaced());

        LinearLayout quick = card();
        quick.addView(text("Quick Setup", 20, true, Color.BLACK));
        quick.addView(text("Do these once, then use the floating CB bubble while you are inside CapCut.", 14, false, Color.DKGRAY));
        Button overlay = button("1. Allow Floating Bubble");
        overlay.setOnClickListener(v -> requestOverlay());
        quick.addView(overlay, buttonParams());
        Button accessibility = button("2. Enable CaptionBrain Accessibility");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        quick.addView(accessibility, buttonParams());
        Button bubble = button("3. Show Floating CB Bubble");
        bubble.setOnClickListener(v -> startBubble());
        quick.addView(bubble, buttonParams());
        root.addView(quick, spaced());

        LinearLayout workflow = card();
        workflow.addView(text("Your Workflow", 20, true, Color.BLACK));
        workflow.addView(text("Open CapCut → manually open your project → tap the floating CB logo → press START AI. The bubble can be dragged to either side of the screen.", 15, false, Color.DKGRAY));
        Button capcut = button("Open CapCut");
        capcut.setOnClickListener(v -> launchCapCut());
        workflow.addView(capcut, buttonParams());
        root.addView(workflow, spaced());

        LinearLayout state = card();
        state.addView(text("System Status", 20, true, Color.BLACK));
        status = text("Checking…", 14, false, Color.DKGRAY);
        status.setPadding(0, dp(8), 0, 0);
        state.addView(status);
        root.addView(state, spaced());

        TextView note = text("Prototype v0.1 • User-triggered overlay automation only", 12, false, Color.GRAY);
        note.setGravity(Gravity.CENTER);
        root.addView(note);
        return scroll;
    }

    private void requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } else {
            Toast.makeText(this, "Floating overlay is already allowed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void startBubble() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            requestOverlay();
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 22);
        }
        Intent service = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service); else startService(service);
        Toast.makeText(this, "CB bubble started. Open CapCut and drag the bubble where you want it.", Toast.LENGTH_LONG).show();
    }

    private void launchCapCut() {
        PackageManager pm = getPackageManager();
        String[] ids = {"com.lemon.lvoverseas", "com.lemon.lv"};
        for (String id : ids) {
            Intent i = pm.getLaunchIntentForPackage(id);
            if (i != null) { startActivity(i); return; }
        }
        Toast.makeText(this, "CapCut was not found on this device.", Toast.LENGTH_LONG).show();
    }

    private void refreshStatus() {
        if (status == null) return;
        boolean overlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        boolean acc = CapCutAccessibilityService.isEnabled(this);
        status.setText("Floating bubble: " + (overlay ? "READY" : "permission needed") + "\n" +
                "Accessibility bridge: " + (acc ? "READY" : "enable in Settings") + "\n" +
                "Reference brain: LOADED (5-video profile)");
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(18), dp(18), dp(18));
        l.setBackground(roundRect(Color.WHITE, 20));
        l.setElevation(dp(2));
        return l;
    }

    private LinearLayout.LayoutParams spaced() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, dp(16));
        return p;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
        p.setMargins(0, dp(12), 0, 0);
        return p;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(roundRect(Color.rgb(20,20,20), 16));
        return b;
    }

    private TextView text(String s, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLineSpacing(0, 1.12f);
        return t;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
}
