# CaptionBrain Mobile v0.1

Android prototype for a user-triggered floating CapCut caption assistant.

## What works in v0.1
- Separate Android app; does **not** install inside CapCut.
- Draggable `CB` bubble can stay over CapCut.
- Tap bubble for START AI / PAUSE / STOP.
- Opens CapCut from the dashboard.
- Accessibility bridge detects whether CapCut is foreground and can click visible, accessibility-exposed Text / Auto Captions controls.
- Includes a local 5-reference caption-style profile and deterministic style selector for future visual/transcript inputs.

## Important technical boundary
Android normally does not allow one app to directly read another app's private CapCut project/audio files. A production version therefore needs a user-approved MediaProjection capture path and, where permitted by the source app, audio playback capture or an explicitly supplied voiceover file. Visual analysis can then feed the included style engine. CapCut UI labels also change by version/region, so automation must verify each visible control rather than hard-code coordinates.

## Build
Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).
The project targets Android 13 behavior (targetSdk 33) and compiles with SDK 35.
