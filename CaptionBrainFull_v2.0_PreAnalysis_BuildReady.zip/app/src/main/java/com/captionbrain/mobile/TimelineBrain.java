package com.captionbrain.mobile;

import android.graphics.Bitmap;
import android.graphics.PointF;

import java.util.ArrayList;
import java.util.List;

/** Detects the orange CapCut caption blocks in the user's timeline layout. */
public final class TimelineBrain {
    private TimelineBrain() {}

    public static List<PointF> findVisibleCaptionBlocks(Bitmap bmp) {
        List<PointF> out = new ArrayList<>();
        if (bmp == null) return out;
        int w = bmp.getWidth(), h = bmp.getHeight();
        int y0 = (int)(h * .62f), y1 = (int)(h * .78f);
        int x0 = (int)(w * .08f), x1 = (int)(w * .99f);
        if (y1 <= y0 || x1 <= x0) return out;

        // Find the strongest horizontal orange band first. This avoids the tiny yellow marker
        // on the video track and focuses on the caption row itself.
        int bestY = -1, bestCount = 0;
        int yStep = Math.max(2, h / 1200);
        int xStep = Math.max(2, w / 540);
        for (int y=y0; y<y1; y+=yStep) {
            int count = 0;
            for (int x=x0; x<x1; x+=xStep) if (isCaptionOrange(bmp.getPixel(x,y))) count++;
            if (count > bestCount) { bestCount = count; bestY = y; }
        }
        if (bestY < 0 || bestCount < 8) return out;

        boolean[] active = new boolean[w];
        int halfBand = Math.max(12, h / 150);
        for (int x=x0; x<x1; x++) {
            int hits = 0;
            for (int y=Math.max(y0,bestY-halfBand); y<=Math.min(y1-1,bestY+halfBand); y+=3) {
                if (isCaptionOrange(bmp.getPixel(x,y))) hits++;
            }
            active[x] = hits >= 3;
        }

        int start = -1;
        for (int x=x0; x<=x1; x++) {
            boolean on = x<x1 && active[x];
            if (on && start<0) start=x;
            if ((!on || x==x1) && start>=0) {
                int end=x;
                if (end-start >= Math.max(14,w/80)) {
                    int cx=(start+end)/2;
                    out.add(new PointF(cx/(float)w, bestY/(float)h));
                }
                start=-1;
            }
        }
        return out;
    }

    private static boolean isCaptionOrange(int c) {
        int r=(c>>16)&255, g=(c>>8)&255, b=c&255;
        // Covers the bright and compressed/dim orange seen in the user's screen recording.
        return r>128 && g>58 && g<185 && b<105 && r > g*1.17f;
    }
}
