package com.captionbrain.mobile;

public final class AnalysisState {
    public static volatile boolean running = false;
    public static volatile int progress = 0;
    public static volatile String message = "Idle";
    public static volatile String error = null;

    private AnalysisState() {}

    public static void reset() {
        running = false;
        progress = 0;
        message = "Idle";
        error = null;
    }

    public static void update(int p, String m) {
        progress = Math.max(0, Math.min(100, p));
        message = m == null ? "" : m;
    }
}
