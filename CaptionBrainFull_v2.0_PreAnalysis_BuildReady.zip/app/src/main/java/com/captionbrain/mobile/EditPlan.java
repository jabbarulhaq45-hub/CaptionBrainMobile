package com.captionbrain.mobile;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public final class EditPlan {
    public String sourceUri = "";
    public String sourceName = "";
    public long durationMs = 0L;
    public long analyzedAtMs = 0L;
    public boolean analysisComplete = false;
    public boolean transcriptAvailable = false;
    public String speechSource = "none";
    public String globalPalette = "AUTO";
    public String notes = "";
    public final List<VisualPoint> visuals = new ArrayList<>();
    public final List<Segment> segments = new ArrayList<>();

    public static final class VisualPoint {
        public long timeMs;
        public float brightness;
        public float edgeDensity;
        public String safestZone = "lower-center";
        public int faceCount;
        public boolean light;

        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("timeMs", timeMs);
            o.put("brightness", brightness);
            o.put("edgeDensity", edgeDensity);
            o.put("safestZone", safestZone);
            o.put("faceCount", faceCount);
            o.put("light", light);
            return o;
        }

        static VisualPoint fromJson(JSONObject o) {
            VisualPoint v = new VisualPoint();
            v.timeMs = o.optLong("timeMs",0);
            v.brightness = (float)o.optDouble("brightness",.5);
            v.edgeDensity = (float)o.optDouble("edgeDensity",.5);
            v.safestZone = o.optString("safestZone","lower-center");
            v.faceCount = o.optInt("faceCount",0);
            v.light = o.optBoolean("light",false);
            return v;
        }
    }

    public static final class Segment {
        public long startMs;
        public long endMs;
        public String transcript = "";
        public String displayText = "";
        public boolean keep = true;
        public String style = "LIVE_BOLD_WHITE";
        public String layout = "STRAIGHT_LINE";
        public String position = "lower-center";
        public String motion = "none";
        public String color = "white";
        public String fontHint = "bold-sans";
        public int sizePercent = 100;
        public boolean outline = true;
        public String backplate = "none";
        public float confidence = .5f;
        public String reason = "";

        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("startMs",startMs); o.put("endMs",endMs);
            o.put("transcript",transcript); o.put("displayText",displayText);
            o.put("keep",keep); o.put("style",style); o.put("layout",layout);
            o.put("position",position); o.put("motion",motion); o.put("color",color);
            o.put("fontHint",fontHint); o.put("sizePercent",sizePercent); o.put("outline",outline);
            o.put("backplate",backplate); o.put("confidence",confidence); o.put("reason",reason);
            return o;
        }

        static Segment fromJson(JSONObject o) {
            Segment s = new Segment();
            s.startMs=o.optLong("startMs",0); s.endMs=o.optLong("endMs",0);
            s.transcript=o.optString("transcript",""); s.displayText=o.optString("displayText","");
            s.keep=o.optBoolean("keep",true); s.style=o.optString("style","LIVE_BOLD_WHITE");
            s.layout=o.optString("layout","STRAIGHT_LINE"); s.position=o.optString("position","lower-center");
            s.motion=o.optString("motion","none"); s.color=o.optString("color","white");
            s.fontHint=o.optString("fontHint","bold-sans"); s.sizePercent=o.optInt("sizePercent",100);
            s.outline=o.optBoolean("outline",true); s.backplate=o.optString("backplate","none");
            s.confidence=(float)o.optDouble("confidence",.5); s.reason=o.optString("reason","");
            return s;
        }
    }

    public JSONObject toJson() throws Exception {
        JSONObject o = new JSONObject();
        o.put("sourceUri",sourceUri); o.put("sourceName",sourceName); o.put("durationMs",durationMs);
        o.put("analyzedAtMs",analyzedAtMs); o.put("analysisComplete",analysisComplete);
        o.put("transcriptAvailable",transcriptAvailable); o.put("speechSource",speechSource);
        o.put("globalPalette",globalPalette); o.put("notes",notes);
        JSONArray v = new JSONArray(); for (VisualPoint x: visuals) v.put(x.toJson()); o.put("visuals",v);
        JSONArray s = new JSONArray(); for (Segment x: segments) s.put(x.toJson()); o.put("segments",s);
        return o;
    }

    public static EditPlan fromJson(JSONObject o) {
        EditPlan p = new EditPlan();
        p.sourceUri=o.optString("sourceUri",""); p.sourceName=o.optString("sourceName","");
        p.durationMs=o.optLong("durationMs",0); p.analyzedAtMs=o.optLong("analyzedAtMs",0);
        p.analysisComplete=o.optBoolean("analysisComplete",false); p.transcriptAvailable=o.optBoolean("transcriptAvailable",false);
        p.speechSource=o.optString("speechSource","none"); p.globalPalette=o.optString("globalPalette","AUTO");
        p.notes=o.optString("notes","");
        JSONArray va=o.optJSONArray("visuals"); if(va!=null) for(int i=0;i<va.length();i++) p.visuals.add(VisualPoint.fromJson(va.optJSONObject(i)));
        JSONArray sa=o.optJSONArray("segments"); if(sa!=null) for(int i=0;i<sa.length();i++) p.segments.add(Segment.fromJson(sa.optJSONObject(i)));
        return p;
    }
}
