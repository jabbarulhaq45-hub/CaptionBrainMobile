package com.captionbrain.mobile;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ComponentName;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.graphics.Path;
import android.graphics.PointF;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Handler;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Executor;

/**
 * User-triggered CapCut caption automation engine.
 *
 * Flow:
 *  1) verify a CapCut project is foreground
 *  2) open Captions -> Auto Captions and generate captions
 *  3) inspect the current video frame using Accessibility screenshot capture
 *  4) read accessible caption strings, score semantics and select a 5-reference style
 *  5) enter each caption's visible editing controls and apply style / animation / placement
 *
 * CapCut changes its UI between versions/regions. All actions prefer semantic labels and verify
 * the active window. Gesture fallbacks are normalized rather than hard-coded pixels.
 */
public class CapCutAccessibilityService extends AccessibilityService {
    private static CapCutAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile boolean paused = false;
    private volatile boolean stopped = false;
    private volatile boolean running = false;
    private StatusCallback callback;
    private VisualBrain.SceneVisual lastVisual;
    private int styledCount = 0;
    private int deletedCount = 0;
    private int emptyTimelinePages = 0;
    private final Set<String> seenCaptions = new HashSet<>();
    private EditPlan activePlan;

    private static final String[] CAPCUT_PACKAGES = {"com.lemon.lvoverseas", "com.lemon.lv"};

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        AutomationLog.add(this, "Accessibility service connected");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() {
        if (instance == this) instance = null;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    public static boolean isEnabled(Context context) {
        String expected = new ComponentName(context, CapCutAccessibilityService.class).flattenToString();
        String enabled = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) if (expected.equalsIgnoreCase(splitter.next())) return true;
        return false;
    }

    public static boolean available() { return instance != null; }

    public static void pauseAutomation(boolean p) {
        if (instance == null) return;
        instance.paused = p;
        instance.emit(p ? "Paused" : "Resumed");
        if (!p && instance.running) instance.handler.post(instance::resumeFromCurrentScreen);
    }

    public static void stopAutomation() {
        if (instance == null) return;
        instance.stopped = true;
        instance.running = false;
        instance.handler.removeCallbacksAndMessages(null);
        instance.emit("Stopped");
    }

    public static void startCaptionAssist(StatusCallback cb) {
        if (instance == null) {
            cb.onStatus("Accessibility bridge is not enabled");
            return;
        }
        instance.startFull(cb);
    }

    private void startFull(StatusCallback cb) {
        if (running) {
            emit("CaptionBrain is already running");
            return;
        }
        callback = cb;
        paused = false;
        stopped = false;
        running = true;
        styledCount = 0;
        deletedCount = 0;
        emptyTimelinePages = 0;
        seenCaptions.clear();
        activePlan = EditPlanStore.load(this);
        AutomationLog.add(this, "START AI pressed • plan=" + (activePlan != null && activePlan.analysisComplete));

        if (activePlan == null || !activePlan.analysisComplete) {
            running = false;
            emit("Analyze/import the video in CaptionBrain first • PLAN READY is required");
            return;
        }

        if (!isCapCutForeground()) {
            running = false;
            emit("Open a CapCut project first, then press START AI");
            return;
        }

        emit("1/6 Analyzing CapCut project + existing caption track…");
        captureBitmap(bmp -> {
            if (bmp != null) {
                lastVisual = VisualBrain.analyze(bmp);
                List<PointF> existing = TimelineBrain.findVisibleCaptionBlocks(bmp);
                AutomationLog.add(this, "Initial timeline caption blocks=" + existing.size());
                bmp.recycle();
                if (!existing.isEmpty()) {
                    emit("Existing caption timing found • using it as the voice transcript map");
                    handler.postDelayed(() -> startTimelineTransform(0), 300);
                    return;
                }
            }
            handler.postDelayed(this::openCaptionsStage, 250);
        });
    }

    private void openCaptionsStage() {
        if (!canContinue()) return;
        emit("2/6 Opening CapCut captions…");

        // If an accidental Text-to-Audio popup is open, dismiss it first. The old build could
        // trigger this because it used broad substring matches such as "Caption" and "Continue".
        if (hasAnyText(new String[]{"Convert text to audio", "Current captions will be deleted"})) {
            emit("Closing the wrong CapCut popup…");
            performGlobalAction(GLOBAL_ACTION_BACK);
            handler.postDelayed(this::openCaptionsStage, 450);
            return;
        }

        // On some CapCut builds the Auto Captions sheet may already be open.
        if (isAutoCaptionsDialogVisible()) {
            handler.postDelayed(this::generateStage, 250);
            return;
        }

        // Prefer an exact label so we do not hit Caption Templates / current caption clips.
        boolean captions = clickExactAny(new String[]{"Captions"});
        if (!captions) {
            // User's current CapCut layout: Captions is the far-right bottom toolbar item.
            tapNormalized(.915f, .949f);
        }

        handler.postDelayed(() -> {
            if (!canContinue()) return;
            openAutoCaptionsPanel(0);
        }, 850);
    }

    private void openAutoCaptionsPanel(int attempt) {
        if (!canContinue()) return;

        if (hasAnyText(new String[]{"Convert text to audio", "Current captions will be deleted"})) {
            performGlobalAction(GLOBAL_ACTION_BACK);
            handler.postDelayed(() -> openAutoCaptionsPanel(attempt + 1), 420);
            return;
        }

        if (isAutoCaptionsDialogVisible()) {
            handler.postDelayed(this::generateStage, 220);
            return;
        }

        boolean auto = clickExactAny(new String[]{"Auto Captions", "Auto captions", "Auto caption"});
        if (!auto) {
            // In the user's CapCut build these submenu labels are not exposed to Accessibility.
            // Auto Captions is the second item in the bottom Captions submenu.
            tapNormalized(.465f, .958f);
        }

        handler.postDelayed(() -> {
            if (!canContinue()) return;
            if (isAutoCaptionsDialogVisible()) {
                generateStage();
            } else if (attempt < 3) {
                emit("Opening Auto Captions…");
                openAutoCaptionsPanel(attempt + 1);
            } else {
                running = false;
                emit("Could not open Auto Captions on this CapCut screen");
                dumpVisibleText();
            }
        }, 700);
    }

    private boolean isAutoCaptionsDialogVisible() {
        return hasAnyText(new String[]{"Spoken language", "Generate from"}) ||
                (hasAnyText(new String[]{"Auto detect", "English"}) && hasAnyText(new String[]{"Done"}));
    }

    private void generateStage() {
        if (!canContinue()) return;
        emit("3/6 Starting Auto Captions…");

        // Never click a generic "Continue" button here: the Text-to-Audio warning uses that
        // label too. In the user's current CapCut version Auto Captions uses a bottom Done button.
        if (hasAnyText(new String[]{"Convert text to audio", "Current captions will be deleted"})) {
            performGlobalAction(GLOBAL_ACTION_BACK);
            handler.postDelayed(this::openCaptionsStage, 500);
            return;
        }

        if (isAutoCaptionsDialogVisible()) {
            // Keep the currently selected spoken language if one is already chosen. Prefer Video
            // as the source because the user's narration is mixed into the project video track.
            clickExactAny(new String[]{"Video"});
            handler.postDelayed(() -> {
                boolean done = clickExactAny(new String[]{"Done"});
                if (!done) tapNormalized(.50f, .963f);
                emit("Auto Captions running • waiting for CapCut…");
                handler.postDelayed(() -> waitForCaptionGeneration(0), 700);
            }, 250);
            return;
        }

        boolean started = clickExactAny(new String[]{"Generate", "Create captions", "Create", "Start", "Recognize", "Recognise"});
        if (!started) {
            clickExactAny(new String[]{"Original sound", "From video", "Video", "Sound from video"});
            handler.postDelayed(() -> {
                boolean ok = clickExactAny(new String[]{"Generate", "Create captions", "Create", "Start", "Recognize", "Recognise", "Done"});
                if (!ok && isAutoCaptionsDialogVisible()) tapNormalized(.50f, .963f);
            }, 450);
        }

        emit("Auto Captions running • waiting for CapCut…");
        handler.postDelayed(() -> waitForCaptionGeneration(0), 600);
    }

    private void waitForCaptionGeneration(int tick) {
        if (!canContinue()) return;
        boolean busy = hasAnyText(new String[]{"Generating", "Recognizing", "Recognising", "Processing", "Creating captions"});
        boolean doneSignal = hasAnyText(new String[]{"Batch edit", "Edit captions", "Caption style", "Style"});

        if (doneSignal || (!busy && tick >= 8) || tick >= 35) {
            handler.postDelayed(this::captionEditStage, 600);
            return;
        }
        emit("Auto Captions • " + Math.min(95, 10 + tick * 3) + "%");
        handler.postDelayed(() -> waitForCaptionGeneration(tick + 1), 900);
    }

    private void captionEditStage() {
        if (!canContinue()) return;
        emit("4/6 Reading caption timing + analyzing visuals…");
        captureVisual(() -> {
            if (!canContinue()) return;
            boolean batch = clickAny(new String[]{"Batch edit", "Batch Edit", "Edit captions", "Caption editing"});
            handler.postDelayed(() -> processVisibleCaptionPage(0, batch ? 0 : 1), batch ? 700 : 300);
        });
    }

    private void processVisibleCaptionPage(int page, int noBatchMode) {
        if (!canContinue()) return;
        if (page >= 12) {
            finishSuccess();
            return;
        }

        List<CaptionNode> nodes = collectCaptionNodes();
        List<CaptionNode> fresh = new ArrayList<>();
        for (CaptionNode c : nodes) {
            String key = c.text.toLowerCase(Locale.US).trim();
            if (!seenCaptions.contains(key)) {
                seenCaptions.add(key);
                fresh.add(c);
            }
        }

        if (fresh.isEmpty()) {
            // Try timeline/list scrolling. If scrolling stops, finish.
            if (!scrollForward()) {
                if (styledCount == 0 && noBatchMode == 1) {
                    emit("CapCut hides caption rows • switching to timeline visual mode…");
                    AutomationLog.add(this, "No accessible rows; starting interface-calibrated timeline mode");
                    handler.postDelayed(() -> startTimelineTransform(0), 350);
                    return;
                }
                finishSuccess();
            } else {
                handler.postDelayed(() -> processVisibleCaptionPage(page + 1, noBatchMode), 550);
            }
            return;
        }

        processCaptionList(fresh, 0, () -> {
            if (!canContinue()) return;
            boolean scrolled = scrollForward();
            handler.postDelayed(() -> {
                if (scrolled) processVisibleCaptionPage(page + 1, noBatchMode);
                else finishSuccess();
            }, 500);
        });
    }

    private void processCaptionList(List<CaptionNode> list, int index, Runnable done) {
        if (!canContinue()) return;
        if (index >= list.size()) { done.run(); return; }

        CaptionNode c = list.get(index);
        emit("Styling caption " + (styledCount + 1) + " • “" + shorten(c.text, 28) + "”");

        if (!clickNodeOrParent(c.node)) {
            handler.postDelayed(() -> processCaptionList(list, index + 1, done), 120);
            return;
        }

        handler.postDelayed(() -> {
            if (!canContinue()) return;
            captureVisual(() -> {
                EditPlan.Segment planned = PlanMatcher.best(c.text, activePlan);
                if (planned != null && !planned.keep) {
                    AutomationLog.add(this, "Plan says remove accessible caption: " + c.text);
                    boolean del = clickExactAny(new String[]{"Delete"});
                    if (del) deletedCount++;
                    handler.postDelayed(() -> processCaptionList(list, index + 1, done), 220);
                    return;
                }
                ReferenceCaptionBrain.Decision d = planned == null
                        ? ReferenceCaptionBrain.decide(c.text, lastVisual)
                        : decisionFromPlan(planned, lastVisual);
                applyDecision(d, () -> {
                    styledCount++;
                    handler.postDelayed(() -> processCaptionList(list, index + 1, done), 220);
                });
            });
        }, 300);
    }

    private void applyDecision(ReferenceCaptionBrain.Decision d, Runnable done) {
        if (!canContinue()) return;
        AutomationLog.add(this, "Decision: " + d.style + " / " + d.position + " / " + d.colorName + " / " + d.motion);

        boolean styleOpened = clickAny(new String[]{"Style", "Text style", "Styles"});
        handler.postDelayed(() -> {
            if (!canContinue()) return;
            if (styleOpened) {
                // Font family hints from the references. These are semantic candidates because CapCut font packs vary.
                clickAny(new String[]{"Font"});
                if (d.fontHint.contains("serif")) clickAny(new String[]{"Serif", "Classic", "Times"});
                else if (d.fontHint.contains("extra-bold")) clickAny(new String[]{"Bold", "Heavy", "Impact"});
                else clickAny(new String[]{"System", "Sans", "Bold"});

                // Color selection if CapCut exposes color names/content descriptions.
                clickAny(new String[]{"Color", "Text color"});
                if ("yellow".equals(d.colorName)) clickAny(new String[]{"Yellow"});
                else if ("red".equals(d.colorName)) clickAny(new String[]{"Red", "Dark red"});
                else if ("black".equals(d.colorName)) clickAny(new String[]{"Black"});
                else if ("purple".equals(d.colorName)) clickAny(new String[]{"Purple", "Violet"});
                else if ("blue".equals(d.colorName)) clickAny(new String[]{"Blue"});
                else clickAny(new String[]{"White"});

                if (d.outline) {
                    clickAny(new String[]{"Stroke", "Outline"});
                }
            }

            // Selective motion only; references do not animate every word.
            if (!"none".equals(d.motion)) {
                clickAny(new String[]{"Animation", "Animations"});
                handler.postDelayed(() -> {
                    if ("soft-fade".equals(d.motion)) clickAny(new String[]{"Fade", "Fade in"});
                    else if ("glow-slide-up".equals(d.motion)) clickAny(new String[]{"Slide up", "Up", "Fade in"});
                    else if ("flicker".equals(d.motion)) clickAny(new String[]{"Flicker", "Flash", "Glitch"});
                    else if ("shine-sweep".equals(d.motion)) clickAny(new String[]{"Shine", "Sweep", "Light"});
                    else clickAny(new String[]{"Pop", "Pop up", "Bounce", "Zoom"});
                    moveSelectedCaptionTo(d.position);
                    done.run();
                }, 160);
            } else {
                moveSelectedCaptionTo(d.position);
                done.run();
            }
        }, 220);
    }

    private ReferenceCaptionBrain.Decision decisionFromPlan(EditPlan.Segment s, VisualBrain.SceneVisual liveVisual) {
        ReferenceCaptionBrain.Style style;
        try { style = ReferenceCaptionBrain.Style.valueOf(s.style); }
        catch (Throwable t) { style = ReferenceCaptionBrain.Style.LIVE_BOLD_WHITE; }
        String pos = s.position == null ? "lower-center" : s.position;
        // Live CapCut preview is the final safety check. If a face/busy scene is detected,
        // prefer the live safest zone over the pre-analysis location.
        if (liveVisual != null && (liveVisual.faceCount > 0 || liveVisual.edgeDensity > .55f)) pos = liveVisual.safestZone;
        return new ReferenceCaptionBrain.Decision(style, pos, s.motion, s.color, s.fontHint, s.sizePercent, s.outline);
    }

    private void moveSelectedCaptionTo(String zone) {
        // Calibrated from the user's supplied 1080x2400 CapCut recording. The preview is
        // roughly y=.10-.42; default auto captions sit near lower-center of that preview.
        float tx=.50f, ty=.34f;
        if (zone.contains("left")) tx=.28f;
        else if (zone.contains("right")) tx=.72f;
        if (zone.startsWith("top")) ty=.19f;
        else if (zone.startsWith("mid")) ty=.27f;
        else ty=.34f;
        dragNormalized(.50f, .33f, tx, ty, 280);
    }

    /**
     * Visual fallback for this exact CapCut layout when caption rows are hidden from Android
     * Accessibility. Orange caption clips are detected directly from the timeline screenshot.
     */
    private void startTimelineTransform(int page) {
        if (!canContinue()) return;
        if (page > 220) { finishSuccess(); return; }
        emit("5/6 Selective caption brain • timeline page " + (page + 1));

        captureBitmap(bmp -> {
            if (!canContinue()) { if (bmp != null) bmp.recycle(); return; }
            List<PointF> blocks = bmp == null ? new ArrayList<>() : TimelineBrain.findVisibleCaptionBlocks(bmp);
            if (bmp != null) {
                lastVisual = VisualBrain.analyze(bmp);
                AutomationLog.add(this, "Timeline blocks=" + blocks.size() + " safe=" + lastVisual.safestZone + " faces=" + lastVisual.faceCount);
                bmp.recycle();
            }

            if (blocks.isEmpty()) {
                emptyTimelinePages++;
                if (emptyTimelinePages >= 3) { finishSuccess(); return; }
                scrollTimelineForward();
                handler.postDelayed(() -> startTimelineTransform(page + 1), 650);
                return;
            }

            final int seenBefore = seenCaptions.size();
            processTimelineBlocks(blocks, 0, () -> {
                if (seenCaptions.size() == seenBefore) emptyTimelinePages++; else emptyTimelinePages = 0;
                if (emptyTimelinePages >= 3) { finishSuccess(); return; }
                scrollTimelineForward();
                handler.postDelayed(() -> startTimelineTransform(page + 1), 700);
            });
        });
    }

    private void processTimelineBlocks(List<PointF> blocks, int index, Runnable done) {
        if (!canContinue()) return;
        if (index >= blocks.size()) { done.run(); return; }

        PointF point = blocks.get(index);
        // Tap the orange caption clip, then double-tap the default caption area in the preview
        // to open CapCut's text editor (confirmed in the user's interface recording).
        tapNormalized(point.x, point.y);
        handler.postDelayed(() -> {
            if (!canContinue()) return;
            doubleTapNormalized(.50f, .33f);
            handler.postDelayed(() -> {
                if (!canContinue()) return;
                AccessibilityNodeInfo edit = findEditableNode(getRootInActiveWindow());
                if (edit == null || edit.getText() == null) {
                    AutomationLog.add(this, "Could not open text editor for timeline block @" + point.x);
                    closeTextEditor();
                    handler.postDelayed(() -> processTimelineBlocks(blocks, index + 1, done), 220);
                    return;
                }

                String original = edit.getText().toString().trim();
                String key = original.toLowerCase(Locale.US);
                if (original.length() < 1 || seenCaptions.contains(key)) {
                    closeTextEditor();
                    handler.postDelayed(() -> processTimelineBlocks(blocks, index + 1, done), 180);
                    return;
                }
                seenCaptions.add(key);

                EditPlan.Segment planned = PlanMatcher.best(original, activePlan);
                boolean keep = planned != null ? planned.keep : CaptionSemanticBrain.shouldKeep(original);
                String display = planned != null ? planned.displayText : CaptionSemanticBrain.selectDisplayText(original);
                if (!keep || display == null || display.isEmpty()) {
                    emit("Removing low-value caption • “" + shorten(original, 24) + "”");
                    closeTextEditor();
                    handler.postDelayed(() -> {
                        boolean del = clickExactAny(new String[]{"Delete"});
                        if (!del) tapNormalized(.90f, .94f);
                        deletedCount++;
                        handler.postDelayed(() -> processTimelineBlocks(blocks, index + 1, done), 260);
                    }, 260);
                    return;
                }

                if (!display.equals(original)) {
                    setEditableText(edit, display);
                    emit("Keeping key phrase • “" + shorten(display, 24) + "”");
                } else {
                    emit("Keeping caption • “" + shorten(display, 24) + "”");
                }

                ReferenceCaptionBrain.Decision decision = planned == null
                        ? ReferenceCaptionBrain.decide(display, lastVisual)
                        : decisionFromPlan(planned, lastVisual);
                applyEditorDecision(decision, planned, () -> {
                    styledCount++;
                    handler.postDelayed(() -> processTimelineBlocks(blocks, index + 1, done), 260);
                });
            }, 520);
        }, 260);
    }

    private AccessibilityNodeInfo findEditableNode(AccessibilityNodeInfo n) {
        if (n == null) return null;
        String cls = String.valueOf(n.getClassName());
        if (n.isEditable() || cls.contains("EditText")) return n;
        for (int i=0;i<n.getChildCount();i++) {
            AccessibilityNodeInfo x = findEditableNode(n.getChild(i));
            if (x != null) return x;
        }
        return null;
    }

    private boolean setEditableText(AccessibilityNodeInfo node, String text) {
        if (node == null) return false;
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        boolean ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        AutomationLog.add(this, "Set text='" + text + "' ok=" + ok);
        return ok;
    }

    private void applyEditorDecision(ReferenceCaptionBrain.Decision d, EditPlan.Segment planned, Runnable done) {
        if (!canContinue()) return;
        AutomationLog.add(this, "Editor decision=" + d.style + " / " + d.position + " / " + d.colorName + " / " + d.motion);

        // The user's editor exposes these tabs directly: Templates, Fonts, Styles, Effects,
        // Animations, Bubbles, Presets. Prefer semantic labels; leave the existing setting if
        // CapCut does not expose a particular grid choice to Accessibility.
        clickExactAny(new String[]{"Fonts", "Font"});
        if (d.fontHint.contains("serif")) clickAny(new String[]{"Serif", "Classic", "Times"});
        else if (d.fontHint.contains("extra-bold")) clickAny(new String[]{"Bold", "Heavy", "Impact"});
        else clickAny(new String[]{"Bold", "System", "Sans"});

        clickExactAny(new String[]{"Styles", "Style"});
        if ("yellow".equals(d.colorName)) clickAny(new String[]{"Yellow"});
        else if ("red".equals(d.colorName)) clickAny(new String[]{"Red", "Dark red"});
        else if ("black".equals(d.colorName)) clickAny(new String[]{"Black"});
        else if ("purple".equals(d.colorName)) clickAny(new String[]{"Purple", "Violet"});
        else if ("blue".equals(d.colorName)) clickAny(new String[]{"Blue"});
        else clickAny(new String[]{"White"});
        if (d.outline) clickAny(new String[]{"Stroke", "Outline"});

        if (planned != null && planned.backplate != null && !"none".equals(planned.backplate)) {
            if ("soft-card".equals(planned.backplate) || "highlight-bar".equals(planned.backplate)) {
                clickExactAny(new String[]{"Bubbles", "Bubble"});
                clickAny(new String[]{"Background", "Highlight", "Box", "Rectangle"});
            }
        }

        if (!"none".equals(d.motion)) {
            clickExactAny(new String[]{"Animations", "Animation"});
            if ("soft-fade".equals(d.motion)) clickAny(new String[]{"Fade", "Fade in"});
            else if ("glow-slide-up".equals(d.motion)) clickAny(new String[]{"Slide up", "Up", "Fade in"});
            else if ("flicker".equals(d.motion)) clickAny(new String[]{"Flicker", "Flash", "Glitch"});
            else if ("shine-sweep".equals(d.motion)) clickAny(new String[]{"Shine", "Sweep", "Light"});
            else clickAny(new String[]{"Pop", "Pop up", "Zoom", "Bounce"});
        }

        if (planned != null && ("ERROR".equals(planned.style) || "WHITE_SERIF_EMOTIONAL".equals(planned.style))) {
            clickExactAny(new String[]{"Effects", "Effect"});
            clickAny(new String[]{"Glow", "Blur", "Shadow"});
        }

        handler.postDelayed(() -> {
            closeTextEditor();
            handler.postDelayed(() -> captureVisual(() -> {
                moveSelectedCaptionTo(d.position);
                done.run();
            }), 300);
        }, 260);
    }

    private void closeTextEditor() {
        // The editor has a large checkmark at the right side around x=.93, y=.46.
        boolean closed = clickExactAny(new String[]{"Done", "Save"});
        if (!closed) tapNormalized(.925f, .465f);
    }

    private void doubleTapNormalized(float x, float y) {
        tapNormalized(x,y);
        handler.postDelayed(() -> tapNormalized(x,y), 90);
    }

    private void scrollTimelineForward() {
        // Drag on the video-thumbnail row, not on the caption row, to move the timeline later.
        dragNormalized(.84f, .66f, .34f, .66f, 430);
    }

    private void finishSuccess() {
        if (stopped) return;
        running = false;
        if (styledCount > 0 || deletedCount > 0) emit("6/6 DONE • kept/styled " + styledCount + " • removed " + deletedCount + " low-value captions");
        else emit("DONE • caption timing created, but this CapCut screen did not expose editable text clips");
        AutomationLog.add(this, "Finished. Styled=" + styledCount + " deleted=" + deletedCount);
    }

    private void resumeFromCurrentScreen() {
        if (!running || stopped) return;
        if (!isCapCutForeground()) { emit("Return to CapCut to resume"); return; }
        captionEditStage();
    }

    private boolean canContinue() {
        if (stopped) return false;
        if (paused) { emit("Paused"); return false; }
        if (!isCapCutForeground()) {
            emit("CapCut is not foreground • return to the project");
            return false;
        }
        return true;
    }

    private void captureBitmap(BitmapCallback callback) {
        if (Build.VERSION.SDK_INT < 30) { callback.onBitmap(null); return; }
        try {
            Executor executor = command -> handler.post(command);
            takeScreenshot(0, executor, new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult result) {
                    Bitmap out = null;
                    try {
                        HardwareBuffer hb = result.getHardwareBuffer();
                        ColorSpace cs = result.getColorSpace();
                        Bitmap hardware = Bitmap.wrapHardwareBuffer(hb, cs);
                        if (hardware != null) out = hardware.copy(Bitmap.Config.ARGB_8888, false);
                        hb.close();
                    } catch (Throwable t) {
                        AutomationLog.add(CapCutAccessibilityService.this, "Screenshot copy error: " + t);
                    }
                    callback.onBitmap(out);
                }
                @Override public void onFailure(int errorCode) {
                    AutomationLog.add(CapCutAccessibilityService.this, "Screenshot failed=" + errorCode);
                    callback.onBitmap(null);
                }
            });
        } catch (Throwable t) {
            AutomationLog.add(this, "takeScreenshot unavailable: " + t);
            callback.onBitmap(null);
        }
    }

    private void captureVisual(Runnable after) {
        if (Build.VERSION.SDK_INT < 30) {
            lastVisual = null;
            after.run();
            return;
        }
        try {
            Executor executor = command -> handler.post(command);
            takeScreenshot(0, executor, new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult result) {
                    try {
                        HardwareBuffer hb = result.getHardwareBuffer();
                        ColorSpace cs = result.getColorSpace();
                        Bitmap hardware = Bitmap.wrapHardwareBuffer(hb, cs);
                        if (hardware != null) {
                            Bitmap bmp = hardware.copy(Bitmap.Config.ARGB_8888, false);
                            lastVisual = VisualBrain.analyze(bmp);
                            AutomationLog.add(CapCutAccessibilityService.this,
                                    "Visual brightness=" + lastVisual.brightness + " edge=" + lastVisual.edgeDensity + " safe=" + lastVisual.safestZone);
                            bmp.recycle();
                        }
                        hb.close();
                    } catch (Throwable t) {
                        AutomationLog.add(CapCutAccessibilityService.this, "Screenshot analyze error: " + t);
                    }
                    after.run();
                }
                @Override public void onFailure(int errorCode) {
                    AutomationLog.add(CapCutAccessibilityService.this, "Screenshot failed=" + errorCode);
                    after.run();
                }
            });
        } catch (Throwable t) {
            AutomationLog.add(this, "takeScreenshot unavailable: " + t);
            after.run();
        }
    }

    private boolean isCapCutForeground() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null) return false;
        String p = root.getPackageName().toString();
        for (String pkg : CAPCUT_PACKAGES) if (pkg.equals(p)) return true;
        return false;
    }

    private boolean clickExactAny(String[] candidates) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        for (String c : candidates) {
            AccessibilityNodeInfo n = findByExactText(root, c.toLowerCase(Locale.US));
            if (n != null && clickNodeOrParent(n)) {
                AutomationLog.add(this, "Clicked exact label: " + c);
                return true;
            }
        }
        return false;
    }

    private AccessibilityNodeInfo findByExactText(AccessibilityNodeInfo node, String needle) {
        if (node == null) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if (t != null && t.toString().trim().toLowerCase(Locale.US).equals(needle)) return node;
        if (d != null && d.toString().trim().toLowerCase(Locale.US).equals(needle)) return node;
        for (int i=0;i<node.getChildCount();i++) {
            AccessibilityNodeInfo out = findByExactText(node.getChild(i), needle);
            if (out != null) return out;
        }
        return null;
    }

    private boolean clickAny(String[] candidates) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        for (String c : candidates) {
            AccessibilityNodeInfo n = findByText(root, c.toLowerCase(Locale.US));
            if (n != null && clickNodeOrParent(n)) {
                AutomationLog.add(this, "Clicked label: " + c);
                return true;
            }
        }
        return false;
    }

    private boolean hasAnyText(String[] candidates) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        for (String c : candidates) if (findByText(root, c.toLowerCase(Locale.US)) != null) return true;
        return false;
    }

    private AccessibilityNodeInfo findByText(AccessibilityNodeInfo node, String needle) {
        if (node == null) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if (t != null && t.toString().toLowerCase(Locale.US).contains(needle)) return node;
        if (d != null && d.toString().toLowerCase(Locale.US).contains(needle)) return node;
        for (int i=0;i<node.getChildCount();i++) {
            AccessibilityNodeInfo out = findByText(node.getChild(i), needle);
            if (out != null) return out;
        }
        return null;
    }

    private boolean clickNodeOrParent(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i=0;i<6 && cur!=null;i++) {
            if (cur.isClickable() && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            cur = cur.getParent();
        }
        return n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private List<CaptionNode> collectCaptionNodes() {
        List<CaptionNode> out = new ArrayList<>();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        collectTextNodes(root, out);
        return out;
    }

    private void collectTextNodes(AccessibilityNodeInfo n, List<CaptionNode> out) {
        if (n == null) return;
        CharSequence cs = n.getText();
        if (cs != null) {
            String s = cs.toString().trim();
            if (looksLikeCaption(s, n)) out.add(new CaptionNode(s, n));
        }
        for (int i=0;i<n.getChildCount();i++) collectTextNodes(n.getChild(i), out);
    }

    private boolean looksLikeCaption(String s, AccessibilityNodeInfo n) {
        if (s.length() < 2 || s.length() > 90) return false;
        String l = s.toLowerCase(Locale.US);
        String[] ui = {"caption","captions","style","font","animation","delete","split","edit","batch edit","effects","overlay","audio","text","export","undo","redo","generate","create","start","cancel","done","save","original sound","from video","video","language","bilingual"};
        for (String x: ui) if (l.equals(x) || l.startsWith(x + " ")) return false;
        int words = s.split("\\s+").length;
        if (words > 16) return false;
        String clazz = String.valueOf(n.getClassName());
        return clazz.contains("Text") || n.isClickable();
    }

    private boolean scrollForward() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo scroll = findScrollable(root);
        if (scroll != null && scroll.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
            AutomationLog.add(this, "Scrolled caption list forward");
            return true;
        }
        return false;
    }

    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n) {
        if (n == null) return null;
        if (n.isScrollable()) return n;
        for (int i=0;i<n.getChildCount();i++) {
            AccessibilityNodeInfo x = findScrollable(n.getChild(i));
            if (x != null) return x;
        }
        return null;
    }

    private void dumpVisibleText() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        List<String> list = new ArrayList<>();
        collectAllText(root, list);
        AutomationLog.add(this, "Visible UI: " + list.toString());
    }

    private void collectAllText(AccessibilityNodeInfo n, List<String> out) {
        if (n == null) return;
        if (n.getText() != null) out.add(n.getText().toString());
        if (n.getContentDescription() != null) out.add("[" + n.getContentDescription() + "]");
        for (int i=0;i<n.getChildCount();i++) collectAllText(n.getChild(i), out);
    }

    private void tapNormalized(float x, float y) {
        if (Build.VERSION.SDK_INT < 24) return;
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        Path p = new Path(); p.moveTo(w*x, h*y);
        GestureDescription g = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,70)).build();
        dispatchGesture(g, null, null);
    }

    private void dragNormalized(float x1, float y1, float x2, float y2, long duration) {
        if (Build.VERSION.SDK_INT < 24) return;
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        Path p = new Path(); p.moveTo(w*x1,h*y1); p.lineTo(w*x2,h*y2);
        GestureDescription g = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,duration)).build();
        dispatchGesture(g, null, null);
    }

    private void emit(String s) {
        AutomationLog.add(this, s);
        if (callback != null) callback.onStatus(s);
    }

    private static String shorten(String s, int n) { return s.length() <= n ? s : s.substring(0,n-1) + "…"; }

    private static final class CaptionNode {
        final String text;
        final AccessibilityNodeInfo node;
        CaptionNode(String text, AccessibilityNodeInfo node) { this.text=text; this.node=node; }
    }

    private interface BitmapCallback { void onBitmap(Bitmap bitmap); }
    public interface StatusCallback { void onStatus(String status); }
}
