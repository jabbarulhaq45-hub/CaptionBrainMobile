package com.captionbrain.mobile;

import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.speech.RecognitionListener;
import android.speech.RecognitionSupport;
import android.speech.RecognitionSupportCallback;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Executor;

/**
 * Attempts full-file speech recognition from decoded PCM on Android 13+.
 * The Android recognition implementation is device-dependent, so failure is non-fatal:
 * CaptionBrain can still use CapCut Auto Captions later as the transcript/timing scaffold.
 */
public final class SpeechFileRecognizer {
    public interface Callback { void onComplete(Result result); }
    public static final class Result {
        public boolean success;
        public String source="none";
        public String error="";
        public final List<String> chunks=new ArrayList<>();
        public String fullText="";
    }

    private SpeechFileRecognizer() {}

    public static void start(Context c, PcmAudioExtractor.Result pcm, Callback cb) {
        Result out=new Result();
        if(Build.VERSION.SDK_INT<33 || pcm==null || pcm.pcmFile==null || !pcm.pcmFile.exists()){
            out.error="File speech recognition requires Android 13+ and decoded audio";
            cb.onComplete(out); return;
        }
        try {
            boolean onDevice=Build.VERSION.SDK_INT>=31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(c);
            SpeechRecognizer sr=onDevice?SpeechRecognizer.createOnDeviceSpeechRecognizer(c):SpeechRecognizer.createSpeechRecognizer(c);
            out.source=onDevice?"android-on-device":"android-system";
            new Session(c,sr,pcm,out,cb).begin();
        } catch(Throwable t){
            out.error=t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage());
            cb.onComplete(out);
        }
    }

    private static final class Session implements RecognitionListener {
        final Context context; final SpeechRecognizer sr; final PcmAudioExtractor.Result pcm;
        final Result result; final Callback cb; final Set<String> seen=new HashSet<>();
        ParcelFileDescriptor pfd; boolean finished=false;
        Session(Context c,SpeechRecognizer s,PcmAudioExtractor.Result p,Result r,Callback cb){this.context=c;sr=s;pcm=p;result=r;this.cb=cb;}

        void begin() throws Exception {
            pfd=ParcelFileDescriptor.open(pcm.pcmFile,ParcelFileDescriptor.MODE_READ_ONLY);
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag());
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);
            i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE,pfd);
            i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT,Math.max(1,pcm.channels));
            i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT);
            i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE,Math.max(8000,pcm.sampleRate));
            i.putExtra(RecognizerIntent.EXTRA_SEGMENTED_SESSION,RecognizerIntent.EXTRA_AUDIO_SOURCE);
            sr.setRecognitionListener(this);
            Executor mainExecutor = command -> new Handler(Looper.getMainLooper()).post(command);
            sr.checkRecognitionSupport(i, mainExecutor, new RecognitionSupportCallback() {
                @Override public void onSupportResult(RecognitionSupport recognitionSupport) {
                    try { sr.startListening(i); } catch (Throwable t) { finish(false, "Recognizer could not start file-audio session: " + t.getMessage()); }
                }
                @Override public void onError(int error) {
                    finish(false, "Recognizer does not confirm file-audio support (" + error + ")");
                }
            });
        }

        private void add(Bundle b){
            if(b==null)return;
            ArrayList<String> list=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if(list==null || list.isEmpty())return;
            String s=list.get(0)==null?"":list.get(0).trim();
            if(s.isEmpty())return;
            String key=s.toLowerCase(Locale.US);
            if(seen.add(key))result.chunks.add(s);
        }

        private void finish(boolean ok,String error){
            if(finished)return;finished=true;
            result.success=ok && !result.chunks.isEmpty();
            if(error!=null)result.error=error;
            StringBuilder sb=new StringBuilder();
            for(String s:result.chunks){if(sb.length()>0)sb.append(' ');sb.append(s);}
            result.fullText=sb.toString().trim();
            try{sr.stopListening();}catch(Throwable ignored){}
            try{sr.destroy();}catch(Throwable ignored){}
            try{if(pfd!=null)pfd.close();}catch(Throwable ignored){}
            cb.onComplete(result);
        }

        @Override public void onReadyForSpeech(Bundle params) {}
        @Override public void onBeginningOfSpeech() {}
        @Override public void onRmsChanged(float rmsdB) {}
        @Override public void onBufferReceived(byte[] buffer) {}
        @Override public void onEndOfSpeech() {}
        @Override public void onError(int error) { finish(false,"SpeechRecognizer error "+error); }
        @Override public void onResults(Bundle results) { add(results); finish(true,null); }
        @Override public void onPartialResults(Bundle partialResults) {}
        @Override public void onEvent(int eventType, Bundle params) {}
        @Override public void onSegmentResults(Bundle segmentResults) { add(segmentResults); }
        @Override public void onEndOfSegmentedSession() { finish(true,null); }
    }
}
