package com.captionbrain.mobile;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Matches a CapCut caption/transcript string to the plan produced before editing. */
public final class PlanMatcher {
    private PlanMatcher() {}
    public static EditPlan.Segment best(String text, EditPlan p){
        if(p==null || p.segments.isEmpty() || text==null)return null;
        String n=norm(text); if(n.isEmpty())return null;
        EditPlan.Segment best=null; float score=.0f;
        for(EditPlan.Segment s:p.segments){
            float x=similarity(n,norm(s.transcript));
            x=Math.max(x,similarity(n,norm(s.displayText)));
            if(x>score){score=x;best=s;}
        }
        return score>=.42f?best:null;
    }

    private static float similarity(String a,String b){
        if(a.isEmpty()||b.isEmpty())return 0;
        if(a.equals(b))return 1;
        if(a.contains(b)||b.contains(a))return .86f;
        Set<String> aa=tokens(a),bb=tokens(b);int inter=0;
        for(String x:aa)if(bb.contains(x))inter++;
        int union=aa.size()+bb.size()-inter;
        return union==0?0:inter/(float)union;
    }
    private static Set<String> tokens(String s){Set<String> o=new HashSet<>();for(String x:s.split(" "))if(x.length()>1)o.add(x);return o;}
    private static String norm(String s){return s.toLowerCase(Locale.US).replaceAll("[^a-z0-9' ]"," ").replaceAll("\\s+"," ").trim();}
}
