package com.captionbrain.mobile;

import java.util.List;

/**
 * Director agent: combines specialist agents into one conflict-resolved edit plan.
 * The specialists are deterministic/local and use the structured tutorial knowledge.
 */
public final class MultiAgentDirector {
    private MultiAgentDirector() {}

    public static EditPlan build(String uri, String name,
                                 ImportedVideoAnalyzer.Result video,
                                 SpeechFileRecognizer.Result speech,
                                 PcmAudioExtractor.Result pcm) {
        EditPlan p=new EditPlan();
        p.sourceUri=uri==null?"":uri; p.sourceName=name==null?"":name;
        p.durationMs=video==null?0:video.durationMs;
        p.analyzedAtMs=System.currentTimeMillis();
        p.analysisComplete=true;
        p.globalPalette=video==null?"AUTO":video.globalPalette;
        if(video!=null)p.visuals.addAll(video.visuals);
        p.transcriptAvailable=speech!=null && speech.success && !speech.fullText.isEmpty();
        p.speechSource=p.transcriptAvailable?speech.source:"capcut-fallback";

        List<SpeechAlignmentBrain.Chunk> chunks = SpeechAlignmentBrain.align(
                speech,
                pcm==null?null:pcm.speechWindows,
                p.durationMs);

        for(SpeechAlignmentBrain.Chunk c:chunks){
            VisualBrain.SceneVisual visual=nearestVisual(p.visuals,c.startMs);
            EditPlan.Segment s=decideSegment(c.text,c.startMs,c.endMs,visual);
            p.segments.add(s);
        }

        if(p.transcriptAvailable){
            p.notes="Full-video visual analysis + Android speech transcript complete. CapCut execution should match caption text to this precomputed plan.";
        }else{
            p.notes="Full-video visual/audio analysis complete. Device speech recognizer did not provide a transcript; CapCut Auto Captions will supply transcript/timing while the pre-analysis and tutorial brain choose final styling.";
        }
        return p;
    }

    public static EditPlan.Segment decideSegment(String transcript,long start,long end,VisualBrain.SceneVisual visual){
        EditPlan.Segment out=new EditPlan.Segment();
        out.startMs=start;out.endMs=end;out.transcript=transcript==null?"":transcript.trim();
        CaptionSemanticBrain.Semantics sem=CaptionSemanticBrain.analyze(out.transcript);
        out.keep=CaptionSemanticBrain.shouldKeep(out.transcript);
        out.displayText=out.keep?CaptionSemanticBrain.selectDisplayText(out.transcript):"";
        if(out.displayText.isEmpty() && out.keep)out.displayText=out.transcript;

        ReferenceCaptionBrain.Decision base=ReferenceCaptionBrain.decide(out.displayText,visual);
        out.layout=AgentBrains.LayoutAgent.choose(out.displayText,sem);
        out.style=AgentBrains.StyleAgent.choose(out.displayText,sem,out.layout,base,visual);
        out.position=visual==null?base.position:visual.safestZone;
        out.motion=AgentBrains.MotionAgent.choose(out.displayText,sem,base,out.layout);
        if ("FLICKER".equals(out.style) || "ERROR".equals(out.style)) out.motion="flicker";
        else if ("GLOW_SLIDE_UP".equals(out.style)) out.motion="glow-slide-up";
        else if ("SHINE".equals(out.style) || "PREMIUM_PURPLE".equals(out.style)) out.motion="shine-sweep";
        out.color=AgentBrains.ColorAgent.choose(sem,visual,base);
        if ("PREMIUM_PURPLE".equals(out.style)) out.color="purple";
        else if ("HIGHLIGHTER".equals(out.style)) out.color=visual!=null && visual.lightBackground?"black":"white";
        out.fontHint=AgentBrains.FontAgent.choose(sem,out.layout,base);
        out.sizePercent=AgentBrains.SizeAgent.choose(out.displayText,sem,out.layout,base.sizePercent);
        out.outline=base.outline || (visual!=null && visual.edgeDensity>.56f);
        out.backplate=AgentBrains.BackgroundAgent.choose(out.layout,base,visual);
        if ("HIGHLIGHTER".equals(out.style)) out.backplate="highlight-bar";
        if ("APPLE_MINIMAL".equals(out.style)) out.backplate="none";
        out.confidence=Math.max(.25f,Math.min(1f,sem.emphasis+(visual==null?0:.05f)));
        out.reason="text="+String.format(java.util.Locale.US,"%.2f",sem.emphasis)+
                ", layout="+out.layout+", visual="+(visual==null?"live":visual.safestZone);
        return out;
    }

    private static VisualBrain.SceneVisual nearestVisual(List<EditPlan.VisualPoint> list,long time){
        if(list==null || list.isEmpty())return null;
        EditPlan.VisualPoint best=list.get(0);long diff=Math.abs(best.timeMs-time);
        for(EditPlan.VisualPoint v:list){long d=Math.abs(v.timeMs-time);if(d<diff){best=v;diff=d;}}
        // Reconstruct a compact scene descriptor. Zone-specific busy values are approximated here;
        // live CapCut screenshots will refine positioning during execution.
        float low=Math.max(.1f,best.edgeDensity*.75f), high=Math.min(1f,best.edgeDensity*1.15f);
        float l=high,c=high,r=high,t=high,m=high,b=high;
        if(best.safestZone.contains("left"))l=low; else if(best.safestZone.contains("right"))r=low; else c=low;
        if(best.safestZone.startsWith("top"))t=low; else if(best.safestZone.startsWith("mid"))m=low; else b=low;
        return new VisualBrain.SceneVisual(best.brightness,best.edgeDensity,l,c,r,t,m,b,best.light,best.safestZone,best.faceCount);
    }
}
