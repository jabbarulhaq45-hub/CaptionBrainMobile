package com.captionbrain.mobile;

import java.util.ArrayList;
import java.util.List;

/** Converts recognizer text into approximate speech-timed chunks using detected voice windows. */
public final class SpeechAlignmentBrain {
    public static final class Chunk {
        public long startMs,endMs; public String text;
        Chunk(long s,long e,String t){startMs=s;endMs=e;text=t;}
    }
    private SpeechAlignmentBrain() {}

    public static List<Chunk> align(SpeechFileRecognizer.Result speech,
                                    List<PcmAudioExtractor.SpeechWindow> windows,
                                    long durationMs) {
        List<Chunk> out=new ArrayList<>();
        if(speech==null || !speech.success || speech.fullText.trim().isEmpty())return out;
        List<String> phrases=splitIntoPhrases(speech.chunks.isEmpty()?speech.fullText:String.join(" ",speech.chunks));
        if(phrases.isEmpty())return out;
        if(windows==null || windows.isEmpty()){
            long step=Math.max(500,durationMs/phrases.size());
            for(int i=0;i<phrases.size();i++)out.add(new Chunk(i*step,Math.min(durationMs,(i+1)*step),phrases.get(i)));
            return out;
        }
        // Allocate phrase times over speech windows according to relative speech duration.
        long speechTotal=0;for(PcmAudioExtractor.SpeechWindow w:windows)speechTotal+=Math.max(1,w.endMs-w.startMs);
        int pi=0;
        for(int wi=0;wi<windows.size() && pi<phrases.size();wi++){
            PcmAudioExtractor.SpeechWindow w=windows.get(wi);
            int remainingPhrases=phrases.size()-pi;
            int remainingWindows=windows.size()-wi;
            int take=Math.max(1,(int)Math.round(remainingPhrases*(Math.max(1,w.endMs-w.startMs)/(double)Math.max(1,speechTotal))));
            take=Math.min(take,remainingPhrases-(remainingWindows-1));
            take=Math.max(1,take);
            long span=Math.max(300,w.endMs-w.startMs);
            for(int j=0;j<take && pi<phrases.size();j++,pi++){
                long s=w.startMs+(span*j/take);
                long e=w.startMs+(span*(j+1)/take);
                out.add(new Chunk(s,e,phrases.get(pi)));
            }
            speechTotal-=Math.max(1,w.endMs-w.startMs);
        }
        while(pi<phrases.size()){
            long s=out.isEmpty()?0:out.get(out.size()-1).endMs;
            long e=Math.min(durationMs,s+1200);
            out.add(new Chunk(s,e,phrases.get(pi++)));
        }
        return out;
    }

    private static List<String> splitIntoPhrases(String text){
        List<String> out=new ArrayList<>();
        String clean=text==null?"":text.replaceAll("\\s+"," ").trim();
        if(clean.isEmpty())return out;
        String[] sentences=clean.split("(?<=[.!?])\\s+");
        for(String sentence:sentences){
            String[] w=sentence.trim().split("\\s+");
            int i=0;
            while(i<w.length){
                int n=Math.min(7,w.length-i);
                // Prefer 3-7 words; keep a short tail with the previous group when possible.
                if(w.length-(i+n)>0 && w.length-(i+n)<3)n=Math.min(w.length-i,n+(w.length-(i+n)));
                StringBuilder b=new StringBuilder();
                for(int j=0;j<n;j++){if(j>0)b.append(' ');b.append(w[i+j]);}
                String p=b.toString().trim(); if(!p.isEmpty())out.add(p); i+=n;
            }
        }
        return out;
    }
}
