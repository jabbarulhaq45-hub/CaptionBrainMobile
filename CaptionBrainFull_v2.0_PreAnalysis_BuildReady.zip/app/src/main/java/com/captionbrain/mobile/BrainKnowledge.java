package com.captionbrain.mobile;

import android.content.Context;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Loads and validates the structured tutorial knowledge embedded in the APK. */
public final class BrainKnowledge {
    private static volatile JSONObject tutorial;
    private static volatile JSONObject uiMap;
    private BrainKnowledge() {}

    public static synchronized boolean ensureLoaded(Context c) {
        if (tutorial != null && uiMap != null) return true;
        try {
            tutorial = new JSONObject(readAsset(c,"knowledge/tutorial_brain_v1.json"));
            uiMap = new JSONObject(readAsset(c,"knowledge/capcut_ui_map.json"));
            return tutorial.optInt("version",0) >= 1 && uiMap.optInt("version",0) >= 1;
        } catch (Throwable t) {
            tutorial = null; uiMap = null; return false;
        }
    }

    public static int tutorialVersion(Context c) {
        return ensureLoaded(c) ? tutorial.optInt("version",0) : 0;
    }

    public static int sourceTutorialCount(Context c) {
        return ensureLoaded(c) && tutorial.optJSONArray("source_tutorials") != null
                ? tutorial.optJSONArray("source_tutorials").length() : 0;
    }

    private static String readAsset(Context c,String path) throws Exception {
        try(InputStream in=c.getAssets().open(path); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
