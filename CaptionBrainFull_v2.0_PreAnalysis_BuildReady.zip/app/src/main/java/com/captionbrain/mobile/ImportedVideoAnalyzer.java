package com.captionbrain.mobile;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;

/** Full-video visual sampler used before CapCut automation starts. */
public final class ImportedVideoAnalyzer {
    public interface Progress { void onProgress(int percent, String message); }

    public static final class Result {
        public long durationMs;
        public int width;
        public int height;
        public final List<EditPlan.VisualPoint> visuals = new ArrayList<>();
        public String globalPalette = "AUTO";
        public float averageBrightness = .5f;
        public float averageClutter = .5f;
        public int sampledFrames = 0;
    }

    private ImportedVideoAnalyzer() {}

    public static Result analyze(Context c, Uri uri, Progress progress) throws Exception {
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        Result out = new Result();
        try {
            mmr.setDataSource(c, uri);
            String d = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            String w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
            String h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            out.durationMs = parseLong(d, 0L);
            out.width = (int)parseLong(w, 0L);
            out.height = (int)parseLong(h, 0L);
            if (out.durationMs <= 0) throw new IllegalStateException("Could not read video duration");

            // Analyze the whole runtime while keeping the workload reasonable on a phone.
            // Up to ~260 samples: ~0.25 s for Shorts, ~4.6 s for a 20-minute video.
            long stepMs = Math.max(250L, out.durationMs / 260L);
            stepMs = Math.min(stepMs, 5000L);
            int count = (int)Math.max(1, (out.durationMs + stepMs - 1) / stepMs);
            float brightSum=0f, edgeSum=0f;

            for (int i=0;i<count;i++) {
                long t = Math.min(out.durationMs-1, i*stepMs);
                Bitmap bmp = frame(mmr, t);
                if (bmp != null) {
                    VisualBrain.SceneVisual v = VisualBrain.analyzeVideoFrame(bmp);
                    EditPlan.VisualPoint p = new EditPlan.VisualPoint();
                    p.timeMs=t; p.brightness=v.brightness; p.edgeDensity=v.edgeDensity;
                    p.safestZone=v.safestZone; p.faceCount=v.faceCount; p.light=v.lightBackground;
                    out.visuals.add(p);
                    brightSum += v.brightness; edgeSum += v.edgeDensity; out.sampledFrames++;
                    bmp.recycle();
                }
                if (progress != null && (i % 3 == 0 || i == count-1)) {
                    int pct = 5 + (int)(45.0 * (i+1) / count);
                    progress.onProgress(pct, "Visual brain • frame " + (i+1) + "/" + count);
                }
            }

            if (out.sampledFrames > 0) {
                out.averageBrightness = brightSum / out.sampledFrames;
                out.averageClutter = edgeSum / out.sampledFrames;
            }
            if (out.averageBrightness > .72f) out.globalPalette = "LIGHT_EDITORIAL";
            else if (out.averageBrightness < .32f) out.globalPalette = "DARK_HIGH_CONTRAST";
            else out.globalPalette = "AUTO_CONTRAST";
            return out;
        } finally {
            try { mmr.release(); } catch (Throwable ignored) {}
        }
    }

    private static Bitmap frame(MediaMetadataRetriever mmr, long ms) {
        try {
            long us = ms * 1000L;
            if (Build.VERSION.SDK_INT >= 27) {
                Bitmap b = mmr.getScaledFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 360, 640);
                if (b != null) return b;
            }
            Bitmap b = mmr.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (b == null) return null;
            int max = 640;
            int w=b.getWidth(), h=b.getHeight();
            if (Math.max(w,h) <= max) return b;
            float s = max/(float)Math.max(w,h);
            Bitmap scaled = Bitmap.createScaledBitmap(b, Math.max(2,(int)(w*s)), Math.max(2,(int)(h*s)), true);
            if (scaled != b) b.recycle();
            return scaled;
        } catch (Throwable t) {
            return null;
        }
    }

    private static long parseLong(String s, long d) {
        try { return Long.parseLong(s); } catch (Throwable t) { return d; }
    }
}
