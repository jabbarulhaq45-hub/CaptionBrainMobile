package com.captionbrain.mobile;

/**
 * Caption style brain distilled from the five supplied reference videos.
 * It combines semantic emphasis + current-frame visual complexity.
 */
public final class ReferenceCaptionBrain {
    public enum Style {
        LIVE_BOLD_WHITE,          // white bold sans over footage
        LIVE_YELLOW_SECONDARY,    // small yellow cinematic line
        CLEAN_BLACK_EDITORIAL,    // black sans/serif on white
        CLEAN_RED_SERIF,          // red/dark-red serif on white/pink
        WHITE_SERIF_EMOTIONAL,    // reflective line over cinematic footage
        IMPACT_SINGLE_WORD,       // oversized single/short punch phrase
        CLEAN_BLUE,
        ERROR,
        APPLE_MINIMAL,
        STACKED_KINETIC,
        HIGHLIGHTER,
        SHINE,
        FLICKER,
        PREMIUM_PURPLE,
        GLOW_SLIDE_UP,
        CURSOR_TYPE
    }

    public static final class Decision {
        public final Style style;
        public final String position;
        public final String motion;
        public final String colorName;
        public final String fontHint;
        public final int sizePercent;
        public final boolean outline;
        public Decision(Style style, String position, String motion, String colorName,
                        String fontHint, int sizePercent, boolean outline) {
            this.style=style; this.position=position; this.motion=motion; this.colorName=colorName;
            this.fontHint=fontHint; this.sizePercent=sizePercent; this.outline=outline;
        }
    }

    private ReferenceCaptionBrain() {}

    public static Decision decide(String caption, VisualBrain.SceneVisual visual) {
        CaptionSemanticBrain.Semantics sem = CaptionSemanticBrain.analyze(caption);
        boolean light = visual != null && visual.lightBackground;
        float busy = visual == null ? .5f : visual.edgeDensity;
        String pos = visual == null ? "lower-center" : visual.safestZone;

        Style style;
        if (sem.punch && !light) style = Style.IMPACT_SINGLE_WORD;
        else if (light && sem.reflective) style = Style.CLEAN_RED_SERIF;
        else if (light && sem.emphasis >= .62f) style = Style.CLEAN_BLACK_EDITORIAL;
        else if (sem.reflective && sem.emphasis >= .62f) style = Style.WHITE_SERIF_EMOTIONAL;
        else if (sem.emphasis < .56f) style = Style.LIVE_YELLOW_SECONDARY;
        else style = Style.LIVE_BOLD_WHITE;

        switch (style) {
            case CLEAN_RED_SERIF:
                return new Decision(style, pos, "soft-fade", "red", "serif", sem.punch ? 118 : 96, false);
            case CLEAN_BLACK_EDITORIAL:
                return new Decision(style, pos, sem.emphasis>.78f?"pop":"none", "black", sem.reflective?"serif":"bold-sans", sem.punch?124:100, false);
            case WHITE_SERIF_EMOTIONAL:
                return new Decision(style, pos, "soft-fade", "white", "serif", 98, busy>.48f);
            case IMPACT_SINGLE_WORD:
                return new Decision(style, pos, "pop", "white", "extra-bold-sans", 138, true);
            case LIVE_YELLOW_SECONDARY:
                return new Decision(style, "lower-center", "none", "yellow", "medium-sans", 78, true);
            default:
                return new Decision(style, pos, sem.emphasis>.82f?"pop":"none", "white", "bold-sans", sem.punch?126:102, true);
        }
    }
}
