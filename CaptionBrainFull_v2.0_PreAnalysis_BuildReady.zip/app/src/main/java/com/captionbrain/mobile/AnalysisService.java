package com.captionbrain.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Foreground service that analyzes an imported video before CapCut execution. */
public class AnalysisService extends Service {
    public static final String EXTRA_URI="uri";
    public static final String EXTRA_NAME="name";
    private static final int NOTIFICATION_ID=78;
    private static final String CHANNEL="captionbrain_analysis";
    private final ExecutorService worker= Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private NotificationManager nm;

    @Override public void onCreate(){
        super.onCreate(); nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL,"CaptionBrain analysis",NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(c);
        }
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String raw=intent==null?null:intent.getStringExtra(EXTRA_URI);
        String name=intent==null?"Imported video":intent.getStringExtra(EXTRA_NAME);
        if(raw==null){stopSelf();return START_NOT_STICKY;}
        Uri uri=Uri.parse(raw);
        AnalysisState.running=true; AnalysisState.error=null; update(1,"Starting full-video analysis");
        startForeground(NOTIFICATION_ID,notification("Starting…",1));
        worker.execute(()->runAnalysis(uri,name));
        return START_NOT_STICKY;
    }

    private void runAnalysis(Uri uri,String name){
        ImportedVideoAnalyzer.Result video=null; PcmAudioExtractor.Result pcm=null;
        try {
            if (!BrainKnowledge.ensureLoaded(this)) throw new IllegalStateException("Tutorial knowledge base is missing or invalid");
            video=ImportedVideoAnalyzer.analyze(this,uri,this::update);
            update(50,"Visual brain complete • decoding voice");
            try { pcm=PcmAudioExtractor.decode(this,uri,this::update); }
            catch(Throwable audioError){
                AutomationLog.add(this,"Audio decode fallback: "+audioError);
                update(72,"Audio decode unavailable • continuing with CapCut transcript fallback");
            }
            final ImportedVideoAnalyzer.Result fv=video;
            final PcmAudioExtractor.Result fp=pcm;
            if(fp==null){
                SpeechFileRecognizer.Result empty=new SpeechFileRecognizer.Result();
                finishPlan(uri,name,fv,fp,empty);
                return;
            }
            update(73,"Voice brain • transcribing imported video");
            AtomicBoolean returned=new AtomicBoolean(false);
            main.post(()->SpeechFileRecognizer.start(this,fp,speech->{
                if(returned.compareAndSet(false,true)) worker.execute(()->finishPlan(uri,name,fv,fp,speech));
            }));
            long speechTimeout = Math.min(900000L, Math.max(180000L, fp.durationMs/2L + 120000L));
            main.postDelayed(()->{
                if(returned.compareAndSet(false,true)){
                    SpeechFileRecognizer.Result timeout=new SpeechFileRecognizer.Result();
                    timeout.error="Speech recognition timed out";
                    worker.execute(()->finishPlan(uri,name,fv,fp,timeout));
                }
            },speechTimeout);
        } catch(Throwable t){
            fail("Analysis failed: "+t.getClass().getSimpleName()+" • "+String.valueOf(t.getMessage()));
        }
    }

    private void finishPlan(Uri uri,String name,ImportedVideoAnalyzer.Result video,
                            PcmAudioExtractor.Result pcm,SpeechFileRecognizer.Result speech){
        try {
            update(90,"Director + specialist agents • building edit plan");
            EditPlan plan=MultiAgentDirector.build(uri.toString(),name,video,speech,pcm);
            EditPlanStore.save(this,plan);
            update(100,plan.transcriptAvailable?"PLAN READY • voice + visuals analyzed":"PLAN READY • visuals analyzed; CapCut will provide transcript timing");
            AnalysisState.running=false;
            AutomationLog.add(this,"Pre-analysis ready. segments="+plan.segments.size()+" visuals="+plan.visuals.size()+" speech="+plan.speechSource);
            stopForeground(false); stopSelf();
        } catch(Throwable t){fail("Could not save edit plan: "+String.valueOf(t.getMessage()));}
    }

    private void fail(String s){
        AnalysisState.running=false; AnalysisState.error=s; AnalysisState.message=s;
        AutomationLog.add(this,s); updateNotification(s,0); stopForeground(false); stopSelf();
    }

    private void update(int p,String s){
        AnalysisState.update(p,s); updateNotification(s,p);
    }
    private void updateNotification(String s,int p){
        try{if(nm!=null)nm.notify(NOTIFICATION_ID,notification(s,p));}catch(Throwable ignored){}
    }
    private Notification notification(String text,int progress){
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,2,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        b.setContentTitle("CaptionBrain video analysis").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_search)
                .setContentIntent(pi).setOngoing(AnalysisState.running);
        if(progress>0&&progress<100)b.setProgress(100,progress,false);
        return b.build();
    }

    @Override public void onDestroy(){worker.shutdownNow();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
