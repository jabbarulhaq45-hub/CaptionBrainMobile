package com.captionbrain.mobile;

import java.util.Locale;

/** Specialist decision agents distilled from Tutorials 001-005. */
public final class AgentBrains {
    private AgentBrains() {}


    public static final class StyleAgent {
        public static String choose(String text, CaptionSemanticBrain.Semantics s, String layout,
                                    ReferenceCaptionBrain.Decision base, VisualBrain.SceneVisual v) {
            String l=text==null?"":text.toLowerCase(Locale.US);
            if(s.negative && s.emphasis>.68f) return "ERROR";
            if(l.contains("premium") || l.contains("luxury")) return "PREMIUM_PURPLE";
            if(l.contains("warning") || l.contains("danger")) return "FLICKER";
            if("DIAGRAMMATIC".equals(layout) && s.emphasis>.62f) return "HIGHLIGHTER";
            if("EDITORIAL_CARD".equals(layout)) return s.reflective?"APPLE_MINIMAL":"GLOW_SLIDE_UP";
            if("CLUSTER".equals(layout) && s.action) return "STACKED_KINETIC";
            if("ONE_ON_ONE".equals(layout) && s.punch) return "IMPACT_SINGLE_WORD";
            if(v!=null && !v.lightBackground && s.emphasis<.58f) return "CLEAN_BLUE";
            return base.style.name();
        }
    }

    public static final class LayoutAgent {
        public static String choose(String text, CaptionSemanticBrain.Semantics s) {
            int words=s.words;
            String l=text==null?"":text.toLowerCase(Locale.US);
            if(words<=2 && s.emphasis>=.68f) return "ONE_ON_ONE";
            if(l.contains("because") || l.contains("vs") || l.contains("versus") || l.contains("how") || l.contains("why")) {
                if(words>=4) return "DIAGRAMMATIC";
            }
            if(words>=4 && words<=7 && s.emphasis>=.62f) return "CLUSTER";
            if(s.reflective && words>=3) return "EDITORIAL_CARD";
            return "STRAIGHT_LINE";
        }
    }

    public static final class BackgroundAgent {
        public static String choose(String layout, ReferenceCaptionBrain.Decision d, VisualBrain.SceneVisual v) {
            if("HIGHLIGHTER".equals(d.style.name())) return "highlight-bar";
            if("EDITORIAL_CARD".equals(layout) && v!=null && v.edgeDensity>.52f) return "soft-card";
            if(v!=null && v.edgeDensity>.58f && !d.outline) return "soft-shadow";
            return "none";
        }
    }

    public static final class MotionAgent {
        public static String choose(String text, CaptionSemanticBrain.Semantics s,
                                    ReferenceCaptionBrain.Decision base, String layout) {
            String l=text==null?"":text.toLowerCase(Locale.US);
            if(s.negative && s.punch) return "flicker";
            if("EDITORIAL_CARD".equals(layout) && s.emphasis>.64f) return "glow-slide-up";
            if("ONE_ON_ONE".equals(layout) && s.emphasis>.78f) return "pop";
            if(l.contains("premium") || l.contains("shine")) return "shine-sweep";
            return base.motion;
        }
    }

    public static final class FontAgent {
        public static String choose(CaptionSemanticBrain.Semantics s, String layout, ReferenceCaptionBrain.Decision base) {
            if("EDITORIAL_CARD".equals(layout) && s.emphasis>.68f) return s.reflective?"serif":"display-sans";
            if("ONE_ON_ONE".equals(layout) && s.punch) return "extra-bold-sans";
            return base.fontHint;
        }
    }

    public static final class ColorAgent {
        public static String choose(CaptionSemanticBrain.Semantics s, VisualBrain.SceneVisual v,
                                    ReferenceCaptionBrain.Decision base) {
            if(s.negative && s.emphasis>.68f) return "red";
            if(v!=null && v.lightBackground && "white".equals(base.colorName)) return "black";
            return base.colorName;
        }
    }

    public static final class SizeAgent {
        public static int choose(String text, CaptionSemanticBrain.Semantics s, String layout, int base) {
            int n=text==null?0:text.length();
            int out=base;
            if("ONE_ON_ONE".equals(layout)) out=Math.max(out,132);
            else if("CLUSTER".equals(layout)) out=Math.min(out,108);
            else if(n>26) out=Math.min(out,88);
            else if(n>18) out=Math.min(out,96);
            return Math.max(72,Math.min(145,out));
        }
    }
}
