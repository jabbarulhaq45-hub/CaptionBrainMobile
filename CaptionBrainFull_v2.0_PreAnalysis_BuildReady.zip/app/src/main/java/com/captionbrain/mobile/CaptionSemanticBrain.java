package com.captionbrain.mobile;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Text-side brain for selective captions.
 * Auto Captions are used only as transcript/timing scaffolding. This class decides
 * whether a segment deserves an on-screen caption and, if so, which compact phrase
 * should remain visible.
 */
public final class CaptionSemanticBrain {
    public static final class Semantics {
        public final float emphasis;
        public final boolean reflective;
        public final boolean negative;
        public final boolean action;
        public final boolean punch;
        public final int words;
        public Semantics(float emphasis, boolean reflective, boolean negative, boolean action, boolean punch, int words) {
            this.emphasis=emphasis; this.reflective=reflective; this.negative=negative; this.action=action; this.punch=punch; this.words=words;
        }
    }

    private static final String[] IMPACT = {
            "never","always","must","stop","start","truth","real","only","now","today","change",
            "remember","important","why","because","confidence","success","fail","failure","alone",
            "mind","brain","life","you","fear","power","strong","weak","problem","secret","danger",
            "wrong","right","win","lose","lost","best","worst","money","time","focus","control"
    };
    private static final String[] REFLECT = {
            "think","feel","mind","life","yourself","meaning","remember","believe","imagine","thought",
            "attention","confidence","identity","humble","ego","emotion","psychological","memory"
    };
    private static final String[] ACTION = {
            "go","walk","write","do","make","start","stop","try","build","take","put","ask","choose",
            "watch","move","leave","run","fight","create","change","practice","avoid","learn"
    };
    private static final String[] NEG = {
            "not","don't","dont","never","no","can't","cannot","won't","without","isn't","fear","fail",
            "failure","ruin","wrong","lose","lost"
    };
    private static final String[] STOP = {
            "the","a","an","and","or","but","to","of","for","in","on","at","with","from","is","are",
            "was","were","be","been","being","that","this","it","as","we","they","he","she","i","my",
            "our","your","their","his","her","so","just","very","really","then","than","when","while"
    };

    private CaptionSemanticBrain() {}

    public static Semantics analyze(String caption) {
        String original = caption == null ? "" : caption.trim();
        String s = original.toLowerCase(Locale.US);
        String[] raw = s.isEmpty() ? new String[0] : s.split("\\s+");
        int words = raw.length;
        float score = .38f;
        if (words > 0 && words <= 4) score += .18f;
        if (words == 1) score += .08f;
        if (original.contains("!") || original.contains("?")) score += .12f;

        int impactCount=0;
        for (String k: IMPACT) if (containsWord(s,k)) impactCount++;
        score += Math.min(.32f, impactCount*.09f);

        boolean reflective = containsAny(s, REFLECT);
        boolean action = containsAny(s, ACTION);
        boolean neg = containsAny(s, NEG);
        if (reflective) score += .06f;
        if (action) score += .07f;
        if (neg) score += .05f;

        // Very long, connective narration usually does not need to stay fully on-screen.
        if (words >= 9 && impactCount == 0) score -= .12f;
        if (words >= 13) score -= .06f;

        score = Math.max(.10f, Math.min(1f, score));
        boolean punch = words > 0 && words <= 3 && score >= .72f;
        return new Semantics(score, reflective, neg, action, punch, words);
    }

    /** Keep only segments that add visual value instead of captioning every spoken word. */
    public static boolean shouldKeep(String caption) {
        Semantics s = analyze(caption);
        if (s.words == 0) return false;
        if (s.words <= 2 && s.emphasis >= .52f) return true;
        return s.emphasis >= .57f || s.reflective || s.action || s.negative;
    }

    /**
     * Extracts a short display phrase while preserving the Auto Caption segment timing.
     * This is what lets the app turn a full subtitle segment into an editorial caption.
     */
    public static String selectDisplayText(String caption) {
        if (caption == null) return "";
        String clean = caption.trim().replaceAll("\\s+", " ");
        if (clean.isEmpty()) return clean;

        String[] words = clean.split(" ");
        if (words.length <= 4) return trimPunctuation(clean);

        int best = -1;
        int bestWeight = -1;
        for (int i=0;i<words.length;i++) {
            String n = normalize(words[i]);
            int w = 0;
            if (contains(ImpactBucket.IMPACT, n)) w += 6;
            if (contains(ImpactBucket.REFLECT, n)) w += 4;
            if (contains(ImpactBucket.ACTION, n)) w += 3;
            if (contains(ImpactBucket.NEG, n)) w += 3;
            if (!contains(STOP, n) && n.length() >= 5) w += 2;
            if (i == words.length-1) w += 1;
            if (w > bestWeight) { bestWeight = w; best = i; }
        }

        if (best < 0) best = Math.min(words.length-1, words.length/2);

        // Prefer 1–3 words around the strongest semantic word.
        int start = best;
        int end = best;
        if (best > 0 && !contains(STOP, normalize(words[best-1])) && normalize(words[best-1]).length() > 2) start--;
        if (end-start+1 < 3 && best+1 < words.length && !contains(STOP, normalize(words[best+1]))) end++;

        List<String> picked = new ArrayList<>();
        for (int i=start;i<=end;i++) picked.add(words[i]);
        String phrase = String.join(" ", picked);
        phrase = trimPunctuation(phrase);

        if (phrase.length() > 34) {
            phrase = trimPunctuation(words[best]);
        }
        return phrase;
    }

    private enum ImpactBucket { IMPACT, REFLECT, ACTION, NEG }

    private static boolean contains(ImpactBucket b, String word) {
        switch (b) {
            case IMPACT: return contains(IMPACT, word);
            case REFLECT: return contains(REFLECT, word);
            case ACTION: return contains(ACTION, word);
            default: return contains(NEG, word);
        }
    }

    private static boolean contains(String[] arr, String word) {
        for (String x: arr) if (x.equals(word)) return true;
        return false;
    }

    private static String normalize(String s) {
        return s.toLowerCase(Locale.US).replaceAll("^[^a-z0-9']+|[^a-z0-9']+$", "");
    }

    private static String trimPunctuation(String s) {
        return s.replaceAll("^[\\s,;:.!?\\-]+|[\\s,;:.!?\\-]+$", "").trim();
    }

    private static boolean containsAny(String s, String[] arr) {
        for (String k: arr) if (containsWord(s,k)) return true;
        return false;
    }

    private static boolean containsWord(String s, String word) {
        if (s.equals(word)) return true;
        return (" "+s+" ").contains(" "+word+" ");
    }
}
