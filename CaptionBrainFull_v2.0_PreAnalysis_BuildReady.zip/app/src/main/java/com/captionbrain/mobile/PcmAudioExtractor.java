package com.captionbrain.mobile;

import android.content.Context;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Decodes the imported video's audio track to raw PCM for speech recognition and pause analysis. */
public final class PcmAudioExtractor {
    public static final class SpeechWindow {
        public long startMs, endMs;
        SpeechWindow(long s,long e){startMs=s;endMs=e;}
    }
    public static final class Result {
        public File pcmFile;
        public int sampleRate=16000;
        public int channels=1;
        public int encoding= AudioFormat.ENCODING_PCM_16BIT;
        public long durationMs;
        public final List<SpeechWindow> speechWindows = new ArrayList<>();
    }
    public interface Progress { void onProgress(int percent, String message); }
    private PcmAudioExtractor() {}

    public static Result decode(Context c, Uri uri, Progress progress) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        MediaCodec codec = null;
        FileOutputStream fos = null;
        Result result = new Result();
        try {
            ex.setDataSource(c, uri, null);
            int audio=-1; MediaFormat format=null;
            for(int i=0;i<ex.getTrackCount();i++){
                MediaFormat f=ex.getTrackFormat(i);
                String mime=f.getString(MediaFormat.KEY_MIME);
                if(mime!=null && mime.startsWith("audio/")){audio=i;format=f;break;}
            }
            if(audio<0 || format==null) throw new IllegalStateException("Video has no readable audio track");
            ex.selectTrack(audio);
            String mime=format.getString(MediaFormat.KEY_MIME);
            result.sampleRate = format.containsKey(MediaFormat.KEY_SAMPLE_RATE)?format.getInteger(MediaFormat.KEY_SAMPLE_RATE):16000;
            result.channels = format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)?format.getInteger(MediaFormat.KEY_CHANNEL_COUNT):1;
            result.durationMs = format.containsKey(MediaFormat.KEY_DURATION)?format.getLong(MediaFormat.KEY_DURATION)/1000L:0L;

            codec=MediaCodec.createDecoderByType(mime);
            codec.configure(format,null,null,0); codec.start();
            File dir=new File(c.getCacheDir(),"captionbrain_audio"); if(!dir.exists()) dir.mkdirs();
            File pcm=new File(dir,"analysis_audio.pcm"); result.pcmFile=pcm;
            fos=new FileOutputStream(pcm,false);

            boolean inputDone=false, outputDone=false;
            MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            long fedUs=0;
            while(!outputDone){
                if(!inputDone){
                    int inIndex=codec.dequeueInputBuffer(10000);
                    if(inIndex>=0){
                        ByteBuffer ib=codec.getInputBuffer(inIndex);
                        int size=ib==null?-1:ex.readSampleData(ib,0);
                        if(size<0){codec.queueInputBuffer(inIndex,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true;}
                        else {long pts=ex.getSampleTime(); fedUs=Math.max(fedUs,pts); codec.queueInputBuffer(inIndex,0,size,pts,0); ex.advance();}
                    }
                }
                int outIndex=codec.dequeueOutputBuffer(info,10000);
                if(outIndex==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                    MediaFormat of=codec.getOutputFormat();
                    if(of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) result.sampleRate=of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if(of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) result.channels=of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    if(of.containsKey(MediaFormat.KEY_PCM_ENCODING)) result.encoding=of.getInteger(MediaFormat.KEY_PCM_ENCODING);
                } else if(outIndex>=0){
                    ByteBuffer ob=codec.getOutputBuffer(outIndex);
                    if(ob!=null && info.size>0){
                        ob.position(info.offset); ob.limit(info.offset+info.size);
                        writeAsPcm16(ob,result.encoding,fos);
                    }
                    outputDone=(info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                    codec.releaseOutputBuffer(outIndex,false);
                }
                if(progress!=null && result.durationMs>0){
                    int pct=50+(int)Math.min(20,20.0*(fedUs/1000.0)/result.durationMs);
                    progress.onProgress(pct,"Voice brain • decoding audio");
                }
            }
            fos.flush(); fos.close(); fos=null;
            result.encoding=AudioFormat.ENCODING_PCM_16BIT;
            detectSpeechWindows(result);
            return result;
        } finally {
            try{if(fos!=null)fos.close();}catch(Throwable ignored){}
            try{if(codec!=null){codec.stop();codec.release();}}catch(Throwable ignored){}
            try{ex.release();}catch(Throwable ignored){}
        }
    }

    private static void writeAsPcm16(ByteBuffer b, int encoding, FileOutputStream out) throws Exception {
        if(encoding==AudioFormat.ENCODING_PCM_FLOAT){
            b.order(ByteOrder.nativeOrder());
            byte[] tmp=new byte[8192]; int pos=0;
            while(b.remaining()>=4){
                float f=Math.max(-1f,Math.min(1f,b.getFloat()));
                short s=(short)(f*32767f);
                tmp[pos++]=(byte)(s & 0xff); tmp[pos++]=(byte)((s>>8)&0xff);
                if(pos>=tmp.length-2){out.write(tmp,0,pos);pos=0;}
            }
            if(pos>0)out.write(tmp,0,pos);
        } else {
            byte[] tmp=new byte[Math.min(16384,Math.max(1024,b.remaining()))];
            while(b.hasRemaining()){int n=Math.min(tmp.length,b.remaining());b.get(tmp,0,n);out.write(tmp,0,n);}
        }
    }

    private static void detectSpeechWindows(Result r) throws Exception {
        int bytesPer100ms=Math.max(2,(r.sampleRate*r.channels*2)/10);
        List<Float> energies=new ArrayList<>();
        try(FileInputStream in=new FileInputStream(r.pcmFile)){
            byte[] buf=new byte[bytesPer100ms]; int n;
            while((n=in.read(buf))>1){energies.add(rms16(buf,n));}
        }
        if(energies.isEmpty())return;
        List<Float> sorted=new ArrayList<>(energies); Collections.sort(sorted);
        float median=sorted.get(sorted.size()/2);
        float threshold=Math.max(.010f,Math.min(.12f,median*2.15f+.003f));
        int start=-1, lastActive=-1;
        for(int i=0;i<energies.size();i++){
            boolean active=energies.get(i)>=threshold;
            if(active){if(start<0)start=i;lastActive=i;}
            if(start>=0 && !active && i-lastActive>=4){addWindow(r,start,lastActive+1);start=-1;lastActive=-1;}
        }
        if(start>=0)addWindow(r,start,Math.max(start+1,lastActive+1));
        if(r.speechWindows.isEmpty() && r.durationMs>0)r.speechWindows.add(new SpeechWindow(0,r.durationMs));
    }

    private static void addWindow(Result r,int start100,int end100){
        long s=start100*100L,e=end100*100L;
        if(e-s<250)return;
        if(!r.speechWindows.isEmpty()){
            SpeechWindow prev=r.speechWindows.get(r.speechWindows.size()-1);
            if(s-prev.endMs<400){prev.endMs=e;return;}
        }
        r.speechWindows.add(new SpeechWindow(s,e));
    }

    private static float rms16(byte[] b,int n){
        double sum=0;int count=0;
        for(int i=0;i+1<n;i+=2){short s=(short)((b[i]&255)|(b[i+1]<<8));double f=s/32768.0;sum+=f*f;count++;}
        return count==0?0f:(float)Math.sqrt(sum/count);
    }
}
