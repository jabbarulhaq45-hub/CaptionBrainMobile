package com.captionbrain.mobile;

import android.content.Context;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public final class EditPlanStore {
    private static final String FILE = "captionbrain_edit_plan.json";
    private EditPlanStore() {}

    public static synchronized void save(Context c, EditPlan p) throws Exception {
        File f = new File(c.getFilesDir(), FILE);
        try (FileOutputStream out = new FileOutputStream(f)) {
            out.write(p.toJson().toString(2).getBytes(StandardCharsets.UTF_8));
        }
    }

    public static synchronized EditPlan load(Context c) {
        try {
            File f = new File(c.getFilesDir(), FILE);
            if (!f.exists()) return null;
            byte[] data;
            try (FileInputStream in = new FileInputStream(f); ByteArrayOutputStream buf = new ByteArrayOutputStream()) {
                byte[] tmp = new byte[8192]; int n;
                while ((n = in.read(tmp)) > 0) buf.write(tmp, 0, n);
                data = buf.toByteArray();
            }
            return EditPlan.fromJson(new JSONObject(new String(data, StandardCharsets.UTF_8)));
        } catch (Throwable t) {
            return null;
        }
    }

    public static boolean hasReadyPlan(Context c) {
        EditPlan p = load(c);
        return p != null && p.analysisComplete && p.durationMs > 0;
    }

    public static void clear(Context c) {
        File f = new File(c.getFilesDir(), FILE);
        if (f.exists()) f.delete();
    }
}
