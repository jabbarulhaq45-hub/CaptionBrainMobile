package com.captionbrain.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_VIDEO=104;
    private static final int REQ_AUDIO_PERMISSION=105;
    private TextView status,imported,analysis,planStatus;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final Runnable ticker=new Runnable(){@Override public void run(){refreshStatus();ui.postDelayed(this,900);}};

    @Override public void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState);setContentView(buildUi());refreshStatus();}
    @Override protected void onResume(){super.onResume();refreshStatus();ui.removeCallbacks(ticker);ui.post(ticker);}
    @Override protected void onPause(){ui.removeCallbacks(ticker);super.onPause();}

    private View buildUi(){
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(Color.rgb(247,247,247));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(20),dp(22),dp(20),dp(28));scroll.addView(root);
        root.addView(text("CaptionBrain",30,true,Color.BLACK));
        TextView sub=text("Full pre-analysis + CapCut execution brain",15,false,Color.DKGRAY);sub.setPadding(0,dp(4),0,dp(18));root.addView(sub);

        LinearLayout importCard=card();
        importCard.addView(text("1. Import the same video",20,true,Color.BLACK));
        importCard.addView(text("Choose the exact finished video that you will also place in the CapCut project. CaptionBrain analyzes it before touching CapCut.",14,false,Color.DKGRAY));
        imported=text("No video imported",14,true,Color.rgb(35,35,35));imported.setPadding(0,dp(10),0,0);importCard.addView(imported);
        Button imp=button("Import Video");imp.setOnClickListener(v->chooseVideo());importCard.addView(imp,buttonParams());
        Button analyzeBtn=button("Analyze Full Video + Build Edit Plan");analyzeBtn.setOnClickListener(v->startAnalysis());importCard.addView(analyzeBtn,buttonParams());
        analysis=text("Analysis: idle",13,false,Color.DKGRAY);analysis.setPadding(0,dp(10),0,0);importCard.addView(analysis);
        planStatus=text("Plan: not ready",13,false,Color.DKGRAY);planStatus.setPadding(0,dp(5),0,0);importCard.addView(planStatus);
        root.addView(importCard,spaced());

        LinearLayout brain=card();brain.setBackground(roundRect(Color.rgb(20,20,20),22));
        brain.addView(text("Multi-Agent Tutorial Brain",20,true,Color.WHITE));
        brain.addView(text("Director • Voice/Timing • Text Selector • Typography • Font • Color • Layout • Background/Overlay • Motion • Visual Safe-Zone • Quality Control • CapCut Operator • Recovery",13,false,Color.rgb(230,230,230)));
        TextView details=text("Knowledge loaded from Tutorials 001–005: Clean Blue, Error/Glow, Apple minimal, stacked kinetic captions, gradient, highlighter, shine, flicker, premium purple, Glow Slide Up, cursor/type, Cluster, Straight Line, One-on-One, Diagrammatic, editorial layouts, keyframes, easing and voice-synced text timing.",13,false,Color.rgb(210,210,210));details.setPadding(0,dp(8),0,0);brain.addView(details);root.addView(brain,spaced());

        LinearLayout setup=card();setup.addView(text("2. One-time permissions",20,true,Color.BLACK));
        Button o=button("Allow Floating Bubble");o.setOnClickListener(v->requestOverlay());setup.addView(o,buttonParams());
        Button a=button("Enable CaptionBrain Accessibility");a.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));setup.addView(a,buttonParams());
        Button b=button("Show Floating CB Bubble");b.setOnClickListener(v->startBubble());setup.addView(b,buttonParams());root.addView(setup,spaced());

        LinearLayout flow=card();flow.addView(text("3. Execute in CapCut",20,true,Color.BLACK));
        flow.addView(text("After PLAN READY: open CapCut, put the same video in the project, then tap the floating CB button and START AI. The app uses the precomputed plan, refines against the live CapCut preview, and performs the caption operations automatically.",14,false,Color.DKGRAY));
        Button c=button("Open CapCut");c.setOnClickListener(v->launchCapCut());flow.addView(c,buttonParams());root.addView(flow,spaced());

        LinearLayout state=card();state.addView(text("System status",20,true,Color.BLACK));status=text("Checking…",13,false,Color.DKGRAY);status.setPadding(0,dp(8),0,0);state.addView(status);root.addView(state,spaced());
        TextView note=text("CaptionBrain v2.0 • Full Pre-Analysis Architecture",12,false,Color.GRAY);note.setGravity(Gravity.CENTER);root.addView(note);
        return scroll;
    }

    private void chooseVideo(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("video/*");startActivityForResult(i,REQ_VIDEO);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_VIDEO && resultCode==RESULT_OK && data!=null && data.getData()!=null){
            Uri uri=data.getData();
            try{getContentResolver().takePersistableUriPermission(uri,data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));}catch(Throwable ignored){}
            String name=displayName(uri);VideoImportStore.save(this,uri,name);EditPlanStore.clear(this);AnalysisState.reset();refreshStatus();
            Toast.makeText(this,"Video imported. Now tap Analyze Full Video.",Toast.LENGTH_LONG).show();
        }
    }

    private void startAnalysis(){
        Uri uri=VideoImportStore.loadUri(this);if(uri==null){Toast.makeText(this,"Import a video first.",Toast.LENGTH_LONG).show();return;}
        if(AnalysisState.running){Toast.makeText(this,"Analysis is already running.",Toast.LENGTH_SHORT).show();return;}
        if(checkSelfPermissionCompat(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_AUDIO_PERMISSION);return;
        }
        launchAnalysis(uri);
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQ_AUDIO_PERMISSION){Uri u=VideoImportStore.loadUri(this);if(u!=null)launchAnalysis(u);}
    }

    private void launchAnalysis(Uri uri){
        Intent s=new Intent(this,AnalysisService.class);s.putExtra(AnalysisService.EXTRA_URI,uri.toString());s.putExtra(AnalysisService.EXTRA_NAME,VideoImportStore.loadName(this));
        if(Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);
        Toast.makeText(this,"Full-video analysis started. You can keep this screen open.",Toast.LENGTH_LONG).show();refreshStatus();
    }

    private int checkSelfPermissionCompat(String p){return Build.VERSION.SDK_INT>=23?checkSelfPermission(p):PackageManager.PERMISSION_GRANTED;}

    private String displayName(Uri uri){
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null && c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}
        }catch(Throwable ignored){}
        return "Imported video";
    }

    private void requestOverlay(){
        if(Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this))startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));
        else Toast.makeText(this,"Floating overlay is already allowed.",Toast.LENGTH_SHORT).show();
    }
    private void startBubble(){
        if(Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this)){requestOverlay();return;}
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},22);
        Intent s=new Intent(this,OverlayService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);
        Toast.makeText(this,"CB ready. Open the CapCut project after PLAN READY.",Toast.LENGTH_LONG).show();
    }
    private void launchCapCut(){
        String[] ids={"com.lemon.lvoverseas","com.lemon.lv"};for(String id:ids){Intent i=getPackageManager().getLaunchIntentForPackage(id);if(i!=null){startActivity(i);return;}}
        Toast.makeText(this,"CapCut was not found on this device.",Toast.LENGTH_LONG).show();
    }

    private void refreshStatus(){
        if(imported==null)return;
        Uri uri=VideoImportStore.loadUri(this);imported.setText(uri==null?"No video imported":"Imported: "+VideoImportStore.loadName(this));
        analysis.setText("Analysis: "+(AnalysisState.running?(AnalysisState.progress+"% • "+AnalysisState.message):(AnalysisState.error!=null?AnalysisState.error:AnalysisState.message)));
        EditPlan p=EditPlanStore.load(this);
        if(p!=null && p.analysisComplete){
            String speech=p.transcriptAvailable?("voice transcript ready • "+p.segments.size()+" planned caption beats"):("visual plan ready • transcript will be refined in CapCut");
            planStatus.setText("PLAN READY • "+formatDuration(p.durationMs)+" • "+speech+" • "+p.visuals.size()+" visual samples");
        }else planStatus.setText("Plan: not ready");
        boolean overlay=Build.VERSION.SDK_INT<23||Settings.canDrawOverlays(this);boolean acc=CapCutAccessibilityService.isEnabled(this);
        boolean kb=BrainKnowledge.ensureLoaded(this);
        status.setText("Floating bubble: "+(overlay?"READY":"permission needed")+"\nAccessibility bridge: "+(acc?"READY":"enable in Settings")+"\nTutorial knowledge base: "+(kb?("READY ("+BrainKnowledge.sourceTutorialCount(this)+" tutorials)"):"ERROR")+"\nImported-video visual brain: "+(uri==null?"waiting for video":"READY")+"\nEdit plan: "+(EditPlanStore.hasReadyPlan(this)?"READY":"analyze first"));
    }
    private String formatDuration(long ms){long sec=ms/1000;return String.format(java.util.Locale.US,"%d:%02d",sec/60,sec%60);}

    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(18),dp(18),dp(18),dp(18));l.setBackground(roundRect(Color.WHITE,20));l.setElevation(dp(2));return l;}
    private LinearLayout.LayoutParams spaced(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(16));return p;}
    private LinearLayout.LayoutParams buttonParams(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52));p.setMargins(0,dp(12),0,0);return p;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(roundRect(Color.rgb(20,20,20),16));return b;}
    private TextView text(String s,int sp,boolean bold,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setLineSpacing(0,1.12f);return t;}
    private GradientDrawable roundRect(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+.5f);}
}
