package com.captionbrain.mobile;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class AutomationLog {
    private AutomationLog() {}
    public static synchronized void add(Context c, String msg) {
        try {
            File f = new File(c.getFilesDir(), "captionbrain.log");
            String stamp = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
            try (FileOutputStream out = new FileOutputStream(f, true)) {
                out.write((stamp + "  " + msg + "\n").getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) {}
    }
}
