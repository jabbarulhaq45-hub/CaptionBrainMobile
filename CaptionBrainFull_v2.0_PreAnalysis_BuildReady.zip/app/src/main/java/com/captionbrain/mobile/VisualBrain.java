package com.captionbrain.mobile;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PointF;
import android.media.FaceDetector;

/**
 * Lightweight on-device visual analysis for caption placement and contrast.
 * It looks only at the CapCut preview region, estimates visual clutter, and adds
 * extra penalty around detected faces so captions are less likely to cover them.
 */
public final class VisualBrain {
    public static final class SceneVisual {
        public final float brightness;
        public final float edgeDensity;
        public final float leftBusy, centerBusy, rightBusy;
        public final float topBusy, middleBusy, bottomBusy;
        public final boolean lightBackground;
        public final String safestZone;
        public final int faceCount;

        SceneVisual(float brightness, float edgeDensity, float leftBusy, float centerBusy,
                    float rightBusy, float topBusy, float middleBusy, float bottomBusy,
                    boolean lightBackground, String safestZone, int faceCount) {
            this.brightness = brightness;
            this.edgeDensity = edgeDensity;
            this.leftBusy = leftBusy;
            this.centerBusy = centerBusy;
            this.rightBusy = rightBusy;
            this.topBusy = topBusy;
            this.middleBusy = middleBusy;
            this.bottomBusy = bottomBusy;
            this.lightBackground = lightBackground;
            this.safestZone = safestZone;
            this.faceCount = faceCount;
        }
    }

    private VisualBrain() {}

    /** Analyze a full imported video frame (no CapCut UI crop). */
    public static SceneVisual analyzeVideoFrame(Bitmap frame) {
        if (frame == null || frame.getWidth() < 20 || frame.getHeight() < 20) {
            return new SceneVisual(.45f,.5f,.5f,.5f,.5f,.5f,.5f,.5f,false,"lower-center",0);
        }
        return analyzeRegion(frame, 0, 0, frame.getWidth(), frame.getHeight());
    }

    /** Analyze the visible CapCut preview from a full device screenshot. */
    public static SceneVisual analyze(Bitmap full) {
        if (full == null || full.getWidth() < 20 || full.getHeight() < 20) {
            return new SceneVisual(.45f,.5f,.5f,.5f,.5f,.5f,.5f,.5f,false,"lower-center",0);
        }

        int w = full.getWidth();
        int h = full.getHeight();

        // Calibrated from the user's supplied CapCut interface recording. The preview
        // occupies roughly 10%–42% of the phone screen; everything below is timeline/UI.
        int x0 = (int)(w * .025f), x1 = (int)(w * .975f);
        int y0 = (int)(h * .10f), y1 = (int)(h * .42f);
        if (y1 <= y0 + 20) { y0 = 0; y1 = Math.min(h, (int)(h*.55f)); }

        return analyzeRegion(full, x0, y0, x1, y1);
    }

    private static SceneVisual analyzeRegion(Bitmap full, int x0, int y0, int x1, int y1) {
        int w = full.getWidth();
        int h = full.getHeight();
        x0 = Math.max(0, Math.min(w-2, x0));
        y0 = Math.max(0, Math.min(h-2, y0));
        x1 = Math.max(x0+2, Math.min(w, x1));
        y1 = Math.max(y0+2, Math.min(h, y1));

        int step = Math.max(3, Math.min(x1-x0, y1-y0) / 150);
        float lumSum = 0f;
        int lumN = 0;
        float[] colBusy = new float[3];
        int[] colN = new int[3];
        float[] rowBusy = new float[3];
        int[] rowN = new int[3];
        float edgeSum = 0f;
        int edgeN = 0;

        for (int y = y0 + step; y < y1; y += step) {
            for (int x = x0 + step; x < x1; x += step) {
                int c = full.getPixel(x,y);
                float l = luminance(c);
                lumSum += l; lumN++;
                float gx = Math.abs(l - luminance(full.getPixel(Math.max(x0, x-step), y)));
                float gy = Math.abs(l - luminance(full.getPixel(x, Math.max(y0, y-step))));
                float e = Math.min(1f, (gx + gy) * 2.25f);
                edgeSum += e; edgeN++;
                int ci = Math.min(2, Math.max(0, (int)(3f * (x-x0) / Math.max(1, x1-x0))));
                int ri = Math.min(2, Math.max(0, (int)(3f * (y-y0) / Math.max(1, y1-y0))));
                colBusy[ci] += e; colN[ci]++;
                rowBusy[ri] += e; rowN[ri]++;
            }
        }

        float brightness = lumN == 0 ? .5f : lumSum/lumN;
        float edges = edgeN == 0 ? .5f : edgeSum/edgeN;
        for (int i=0;i<3;i++) {
            colBusy[i] = colN[i] == 0 ? .5f : colBusy[i]/colN[i];
            rowBusy[i] = rowN[i] == 0 ? .5f : rowBusy[i]/rowN[i];
        }

        int faces = applyFacePenalty(full, x0, y0, x1, y1, colBusy, rowBusy);
        int bestC = 1;
        for (int i=0;i<3;i++) if (colBusy[i] + .025f < colBusy[bestC]) bestC=i;
        int bestR = 2;
        if (rowBusy[1] + .02f < rowBusy[bestR]) bestR=1;
        if (rowBusy[0] + .07f < rowBusy[bestR]) bestR=0;

        String[] rows = {"top","mid","lower"};
        String[] cols = {"left","center","right"};
        String zone = rows[bestR] + "-" + cols[bestC];
        return new SceneVisual(brightness, edges, colBusy[0], colBusy[1], colBusy[2],
                rowBusy[0], rowBusy[1], rowBusy[2], brightness > .68f, zone, faces);
    }

    private static int applyFacePenalty(Bitmap full, int x0, int y0, int x1, int y1,
                                        float[] colBusy, float[] rowBusy) {
        try {
            int cw = Math.max(2, x1-x0);
            int ch = Math.max(2, y1-y0);
            if ((cw & 1) == 1) cw--; // FaceDetector requires even width.
            Bitmap crop = Bitmap.createBitmap(full, x0, y0, cw, ch);
            Bitmap rgb565 = crop.copy(Bitmap.Config.RGB_565, false);
            crop.recycle();

            int maxFaces = 8;
            FaceDetector.Face[] found = new FaceDetector.Face[maxFaces];
            FaceDetector detector = new FaceDetector(rgb565.getWidth(), rgb565.getHeight(), maxFaces);
            int count = detector.findFaces(rgb565, found);
            for (int i=0;i<count;i++) {
                FaceDetector.Face f = found[i];
                if (f == null) continue;
                PointF mid = new PointF();
                f.getMidPoint(mid);
                int ci = Math.min(2, Math.max(0, (int)(3f * mid.x / Math.max(1, rgb565.getWidth()))));
                int ri = Math.min(2, Math.max(0, (int)(3f * mid.y / Math.max(1, rgb565.getHeight()))));
                float eye = f.eyesDistance();
                float penalty = .18f + Math.min(.22f, eye / Math.max(1f, rgb565.getWidth()) * 1.8f);
                colBusy[ci] += penalty;
                rowBusy[ri] += penalty;
                // Spill some penalty into neighboring zones for larger faces.
                if (ci>0) colBusy[ci-1] += penalty*.28f;
                if (ci<2) colBusy[ci+1] += penalty*.28f;
                if (ri>0) rowBusy[ri-1] += penalty*.22f;
                if (ri<2) rowBusy[ri+1] += penalty*.22f;
            }
            rgb565.recycle();
            return count;
        } catch (Throwable ignored) {
            return 0;
        }
    }

    private static float luminance(int c) {
        return (0.2126f * Color.red(c) + 0.7152f * Color.green(c) + 0.0722f * Color.blue(c)) / 255f;
    }
}
