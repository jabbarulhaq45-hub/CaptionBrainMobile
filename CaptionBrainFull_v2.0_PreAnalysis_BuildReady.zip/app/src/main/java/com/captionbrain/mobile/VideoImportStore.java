package com.captionbrain.mobile;

import android.content.Context;
import android.net.Uri;

public final class VideoImportStore {
    private static final String PREF = "captionbrain_import";
    private static final String KEY_URI = "video_uri";
    private static final String KEY_NAME = "video_name";

    private VideoImportStore() {}

    public static void save(Context c, Uri uri, String displayName) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString(KEY_URI, uri == null ? null : uri.toString())
                .putString(KEY_NAME, displayName == null ? "Imported video" : displayName)
                .apply();
    }

    public static Uri loadUri(Context c) {
        String s = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_URI, null);
        return s == null ? null : Uri.parse(s);
    }

    public static String loadName(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_NAME, "No video imported");
    }

    public static void clear(Context c) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply();
    }
}
