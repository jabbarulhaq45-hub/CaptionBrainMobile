# CaptionBrain v2.0 — Pre-Analysis + Multi-Agent CapCut Caption Brain

## What changed from v1.x
CaptionBrain now imports the exact video **before** CapCut execution and builds a persistent edit plan.

### Pre-analysis pipeline
1. Import the same video you will put in CapCut.
2. Sample the whole runtime (up to ~260 visual samples).
3. Estimate brightness, visual clutter, faces and safe text zones.
4. Decode the video audio to PCM and detect speech/pause windows.
5. On Android 13+, attempt file-fed Android SpeechRecognizer transcription (on-device model preferred when available).
6. Combine the transcript + voice windows + visuals through specialist agents.
7. Save `captionbrain_edit_plan.json` in app-private storage.

If Android's recognizer does not accept injected file audio on a device, analysis still completes and CapCut Auto Captions becomes the transcript/timing scaffold during execution. The final text remains editable CapCut text, not a burned-in subtitle.

## Specialist brain roles
- Director Agent
- Voice / Timing Agent
- Text Selection Agent
- Typography Agent
- Font Agent
- Color Agent
- Layout Agent
- Background / Overlay Agent
- Motion Agent
- Visual Safe-Zone Agent
- Quality Control Agent
- CapCut Operator
- Recovery Agent

## Tutorial knowledge embedded
Structured knowledge from Tutorials 001–005 is stored under `app/src/main/assets/knowledge/` and used as recipe rules:
- Clean Blue
- Error / strike / glow
- Apple minimal
- stacked kinetic captions
- gradient
- highlighter
- shine
- flicker
- premium purple
- Glow Slide Up
- cursor/type motif
- Cluster / Straight Line / One-on-One / Diagrammatic / Editorial Card layouts
- keyframes, easing, selective accents, voice-synced timing and safe placement

## User workflow
1. Open CaptionBrain.
2. Import the final video.
3. Tap **Analyze Full Video + Build Edit Plan**.
4. Wait for **PLAN READY**.
5. Put the same video into CapCut and open that project.
6. Enable/show the floating CB bubble.
7. Tap **START AI EDIT**.
8. CaptionBrain uses the precomputed plan, CapCut transcript/timing scaffolding when needed, and live screenshot verification to edit the captions.

## Important engineering boundary
CapCut does not expose a public project-editing API to this app. Execution uses Android Accessibility plus screenshot-based verification and calibrated fallbacks. Therefore no build can honestly promise 100% compatibility with every CapCut release, language, device or popup before real-device testing. The architecture is designed to log failures and be recalibrated instead of blindly continuing.
