package com.captionbrain.mobile;

import android.graphics.Bitmap;
import android.graphics.Color;

/** Lightweight on-device visual analysis for caption placement and contrast. */
public final class VisualBrain {
    public static final class SceneVisual {
        public final float brightness;
        public final float edgeDensity;
        public final float leftBusy, centerBusy, rightBusy;
        public final float topBusy, middleBusy, bottomBusy;
        public final boolean lightBackground;
        public final String safestZone;

        SceneVisual(float brightness, float edgeDensity, float leftBusy, float centerBusy,
                    float rightBusy, float topBusy, float middleBusy, float bottomBusy,
                    boolean lightBackground, String safestZone) {
            this.brightness = brightness;
            this.edgeDensity = edgeDensity;
            this.leftBusy = leftBusy;
            this.centerBusy = centerBusy;
            this.rightBusy = rightBusy;
            this.topBusy = topBusy;
            this.middleBusy = middleBusy;
            this.bottomBusy = bottomBusy;
            this.lightBackground = lightBackground;
            this.safestZone = safestZone;
        }
    }

    private VisualBrain() {}

    public static SceneVisual analyze(Bitmap full) {
        if (full == null || full.getWidth() < 20 || full.getHeight() < 20) {
            return new SceneVisual(.45f,.5f,.5f,.5f,.5f,.5f,.5f,.5f,false,"lower-center");
        }

        // CapCut preview normally occupies the upper-middle portion. Cropping away top chrome,
        // timeline and bottom toolbar makes the visual analysis about the actual scene.
        int w = full.getWidth();
        int h = full.getHeight();
        int x0 = (int)(w * .03f), x1 = (int)(w * .97f);
        int y0 = (int)(h * .14f), y1 = (int)(h * .58f);
        if (y1 <= y0 + 10) { y0 = 0; y1 = h; }

        int step = Math.max(3, Math.min(w, h) / 140);
        float lumSum = 0f;
        int lumN = 0;
        float[] colBusy = new float[3];
        int[] colN = new int[3];
        float[] rowBusy = new float[3];
        int[] rowN = new int[3];
        float edgeSum = 0f;
        int edgeN = 0;

        for (int y = y0 + step; y < y1; y += step) {
            for (int x = x0 + step; x < x1; x += step) {
                int c = full.getPixel(x,y);
                float l = luminance(c);
                lumSum += l; lumN++;
                float gx = Math.abs(l - luminance(full.getPixel(Math.max(x0, x-step), y)));
                float gy = Math.abs(l - luminance(full.getPixel(x, Math.max(y0, y-step))));
                float e = Math.min(1f, (gx + gy) * 2.2f);
                edgeSum += e; edgeN++;
                int ci = Math.min(2, Math.max(0, (int)(3f * (x-x0) / Math.max(1, x1-x0))));
                int ri = Math.min(2, Math.max(0, (int)(3f * (y-y0) / Math.max(1, y1-y0))));
                colBusy[ci] += e; colN[ci]++;
                rowBusy[ri] += e; rowN[ri]++;
            }
        }
        float brightness = lumN == 0 ? .5f : lumSum/lumN;
        float edges = edgeN == 0 ? .5f : edgeSum/edgeN;
        for (int i=0;i<3;i++) {
            colBusy[i] = colN[i] == 0 ? .5f : colBusy[i]/colN[i];
            rowBusy[i] = rowN[i] == 0 ? .5f : rowBusy[i]/rowN[i];
        }

        // Prefer the least-busy row/column intersection, but avoid extreme top unless clearly safer.
        int bestC = 1;
        for (int i=0;i<3;i++) if (colBusy[i] + .03f < colBusy[bestC]) bestC=i;
        int bestR = 2;
        if (rowBusy[1] + .025f < rowBusy[bestR]) bestR=1;
        if (rowBusy[0] + .06f < rowBusy[bestR]) bestR=0;
        String[] rows = {"top","mid","lower"};
        String[] cols = {"left","center","right"};
        String zone = rows[bestR] + "-" + cols[bestC];
        return new SceneVisual(brightness, edges, colBusy[0], colBusy[1], colBusy[2],
                rowBusy[0], rowBusy[1], rowBusy[2], brightness > .68f, zone);
    }

    private static float luminance(int c) {
        return (0.2126f * Color.red(c) + 0.7152f * Color.green(c) + 0.0722f * Color.blue(c)) / 255f;
    }
}
