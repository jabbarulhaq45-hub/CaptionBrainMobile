package com.captionbrain.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        refreshStatus();
    }

    @Override protected void onResume() { super.onResume(); refreshStatus(); }

    private View buildUi() {
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(Color.rgb(247,247,247));
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(22),dp(20),dp(28)); scroll.addView(root);
        root.addView(text("CaptionBrain",30,true,Color.BLACK));
        TextView sub=text("Full caption brain for CapCut",15,false,Color.DKGRAY); sub.setPadding(0,dp(4),0,dp(20)); root.addView(sub);

        LinearLayout hero=card(); hero.setBackground(roundRect(Color.rgb(20,20,20),22));
        hero.addView(text("5-Video Editor Brain",19,true,Color.WHITE));
        TextView hb=text("Analyzes the current CapCut visual, uses CapCut Auto Captions for the voiceover, then chooses caption text treatment, font family, color, placement and selective motion from your five references.",14,false,Color.rgb(235,235,235)); hb.setPadding(0,dp(8),0,0); hero.addView(hb); root.addView(hero,spaced());

        LinearLayout setup=card(); setup.addView(text("One-time setup",20,true,Color.BLACK));
        setup.addView(text("After these are enabled, you normally work from the floating CB button inside CapCut.",14,false,Color.DKGRAY));
        Button o=button("1. Allow Floating Bubble"); o.setOnClickListener(v->requestOverlay()); setup.addView(o,buttonParams());
        Button a=button("2. Enable CaptionBrain Accessibility"); a.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); setup.addView(a,buttonParams());
        Button b=button("3. Show Floating CB Bubble"); b.setOnClickListener(v->startBubble()); setup.addView(b,buttonParams()); root.addView(setup,spaced());

        LinearLayout flow=card(); flow.addView(text("How to use",20,true,Color.BLACK));
        flow.addView(text("Open CapCut → open the project yourself → tap CB → START AI CAPTIONS. CaptionBrain opens Auto Captions, waits for transcription, analyzes the visible scene and then edits accessible caption rows automatically.",14,false,Color.DKGRAY));
        Button c=button("Open CapCut"); c.setOnClickListener(v->launchCapCut()); flow.addView(c,buttonParams()); root.addView(flow,spaced());

        LinearLayout brain=card(); brain.addView(text("Reference logic loaded",20,true,Color.BLACK));
        brain.addView(text("• Bold white impact captions over footage\n• Small yellow cinematic support lines\n• Black editorial type on clean light frames\n• Red/dark-red serif accents on reflective light scenes\n• White serif emotional lines\n• Oversized short punch words\n• Captions move toward the least-busy visual zone\n• Motion is selective, not added to every word",14,false,Color.DKGRAY)); root.addView(brain,spaced());

        LinearLayout state=card(); state.addView(text("System status",20,true,Color.BLACK)); status=text("Checking…",14,false,Color.DKGRAY); status.setPadding(0,dp(8),0,0); state.addView(status); root.addView(state,spaced());
        TextView note=text("CaptionBrain v1.0 Full Caption Beta",12,false,Color.GRAY); note.setGravity(Gravity.CENTER); root.addView(note);
        return scroll;
    }

    private void requestOverlay() {
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));
        else Toast.makeText(this,"Floating overlay is already allowed.",Toast.LENGTH_SHORT).show();
    }

    private void startBubble() {
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) { requestOverlay(); return; }
        if (Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},22);
        Intent s=new Intent(this,OverlayService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(s); else startService(s);
        Toast.makeText(this,"CB is ready. Open a CapCut project, tap CB, then START AI CAPTIONS.",Toast.LENGTH_LONG).show();
    }

    private void launchCapCut() {
        String[] ids={"com.lemon.lvoverseas","com.lemon.lv"};
        for(String id:ids){Intent i=getPackageManager().getLaunchIntentForPackage(id);if(i!=null){startActivity(i);return;}}
        Toast.makeText(this,"CapCut was not found on this device.",Toast.LENGTH_LONG).show();
    }

    private void refreshStatus() {
        if(status==null)return;
        boolean overlay=Build.VERSION.SDK_INT<23||Settings.canDrawOverlays(this);
        boolean acc=CapCutAccessibilityService.isEnabled(this);
        status.setText("Floating bubble: "+(overlay?"READY":"permission needed")+"\nAccessibility bridge: "+(acc?"READY":"enable in Settings")+"\nVisual frame brain: READY (Android 11+)\n5-reference style brain: READY\nCapCut caption automation: READY FOR TEST");
    }

    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(18),dp(18),dp(18),dp(18));l.setBackground(roundRect(Color.WHITE,20));l.setElevation(dp(2));return l;}
    private LinearLayout.LayoutParams spaced(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(16));return p;}
    private LinearLayout.LayoutParams buttonParams(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52));p.setMargins(0,dp(12),0,0);return p;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(roundRect(Color.rgb(20,20,20),16));return b;}
    private TextView text(String s,int sp,boolean bold,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setLineSpacing(0,1.12f);return t;}
    private GradientDrawable roundRect(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+.5f);}
}
