package com.captionbrain.mobile;

import java.util.Locale;

/** Text-side brain: scores emphasis and tone from each generated CapCut caption. */
public final class CaptionSemanticBrain {
    public static final class Semantics {
        public final float emphasis;
        public final boolean reflective;
        public final boolean negative;
        public final boolean action;
        public final boolean punch;
        public final int words;
        public Semantics(float emphasis, boolean reflective, boolean negative, boolean action, boolean punch, int words) {
            this.emphasis=emphasis; this.reflective=reflective; this.negative=negative; this.action=action; this.punch=punch; this.words=words;
        }
    }

    private static final String[] IMPACT = {"never","always","must","stop","start","truth","real","only","now","today","change","remember","important","why","because","confidence","success","fail","failure","alone","mind","brain","life","you"};
    private static final String[] REFLECT = {"think","feel","mind","life","yourself","meaning","remember","believe","imagine","thought","attention","confidence"};
    private static final String[] ACTION = {"go","walk","write","do","make","start","stop","try","build","take","put","ask","choose","watch","move"};
    private static final String[] NEG = {"not","don't","dont","never","no","can't","cannot","won't","without","isn't"};

    private CaptionSemanticBrain() {}

    public static Semantics analyze(String caption) {
        String s = caption == null ? "" : caption.trim().toLowerCase(Locale.US);
        String[] raw = s.isEmpty() ? new String[0] : s.split("\\s+");
        int words = raw.length;
        float score = .42f;
        if (words <= 4 && words > 0) score += .18f;
        if (caption != null && (caption.contains("!") || caption.contains("?"))) score += .12f;
        int impactCount=0;
        for (String k: IMPACT) if (containsWord(s,k)) impactCount++;
        score += Math.min(.28f, impactCount*.08f);
        boolean reflective = containsAny(s, REFLECT);
        boolean action = containsAny(s, ACTION);
        boolean neg = containsAny(s, NEG);
        if (action) score += .07f;
        if (neg) score += .05f;
        score = Math.max(.15f, Math.min(1f, score));
        boolean punch = words > 0 && words <= 3 && score >= .75f;
        return new Semantics(score, reflective, neg, action, punch, words);
    }

    private static boolean containsAny(String s, String[] arr) {
        for (String k: arr) if (containsWord(s,k)) return true;
        return false;
    }

    private static boolean containsWord(String s, String word) {
        if (s.equals(word)) return true;
        return (" "+s+" ").contains(" "+word+" ");
    }
}
