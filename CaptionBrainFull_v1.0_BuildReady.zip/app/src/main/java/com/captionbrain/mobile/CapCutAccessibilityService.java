package com.captionbrain.mobile;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ComponentName;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.graphics.Path;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Executor;

/**
 * User-triggered CapCut caption automation engine.
 *
 * Flow:
 *  1) verify a CapCut project is foreground
 *  2) open Captions -> Auto Captions and generate captions
 *  3) inspect the current video frame using Accessibility screenshot capture
 *  4) read accessible caption strings, score semantics and select a 5-reference style
 *  5) enter each caption's visible editing controls and apply style / animation / placement
 *
 * CapCut changes its UI between versions/regions. All actions prefer semantic labels and verify
 * the active window. Gesture fallbacks are normalized rather than hard-coded pixels.
 */
public class CapCutAccessibilityService extends AccessibilityService {
    private static CapCutAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile boolean paused = false;
    private volatile boolean stopped = false;
    private volatile boolean running = false;
    private StatusCallback callback;
    private VisualBrain.SceneVisual lastVisual;
    private int styledCount = 0;
    private final Set<String> seenCaptions = new HashSet<>();

    private static final String[] CAPCUT_PACKAGES = {"com.lemon.lvoverseas", "com.lemon.lv"};

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        AutomationLog.add(this, "Accessibility service connected");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() {
        if (instance == this) instance = null;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    public static boolean isEnabled(Context context) {
        String expected = new ComponentName(context, CapCutAccessibilityService.class).flattenToString();
        String enabled = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) if (expected.equalsIgnoreCase(splitter.next())) return true;
        return false;
    }

    public static boolean available() { return instance != null; }

    public static void pauseAutomation(boolean p) {
        if (instance == null) return;
        instance.paused = p;
        instance.emit(p ? "Paused" : "Resumed");
        if (!p && instance.running) instance.handler.post(instance::resumeFromCurrentScreen);
    }

    public static void stopAutomation() {
        if (instance == null) return;
        instance.stopped = true;
        instance.running = false;
        instance.handler.removeCallbacksAndMessages(null);
        instance.emit("Stopped");
    }

    public static void startCaptionAssist(StatusCallback cb) {
        if (instance == null) {
            cb.onStatus("Accessibility bridge is not enabled");
            return;
        }
        instance.startFull(cb);
    }

    private void startFull(StatusCallback cb) {
        if (running) {
            emit("CaptionBrain is already running");
            return;
        }
        callback = cb;
        paused = false;
        stopped = false;
        running = true;
        styledCount = 0;
        seenCaptions.clear();
        AutomationLog.add(this, "START AI pressed");

        if (!isCapCutForeground()) {
            running = false;
            emit("Open a CapCut project first, then press START AI");
            return;
        }

        emit("1/5 Analyzing current video frame…");
        captureVisual(() -> handler.postDelayed(this::openCaptionsStage, 250));
    }

    private void openCaptionsStage() {
        if (!canContinue()) return;
        emit("2/5 Opening CapCut captions…");

        boolean captions = clickAny(new String[]{"Captions", "Caption", "Text"});
        if (!captions) {
            // Current user layout shows Captions as the far-right bottom tool.
            tapNormalized(.915f, .952f);
        }

        handler.postDelayed(() -> {
            if (!canContinue()) return;
            boolean auto = clickAny(new String[]{"Auto captions", "Auto Captions", "Auto caption", "Auto-captions"});
            if (!auto) {
                emit("Auto Captions panel not exposed yet • rescanning…");
                retryOpenAutoCaptions(0);
            } else {
                handler.postDelayed(this::generateStage, 700);
            }
        }, 850);
    }

    private void retryOpenAutoCaptions(int attempt) {
        if (!canContinue()) return;
        if (attempt >= 5) {
            running = false;
            emit("I reached Captions, but this CapCut version hides Auto Captions from Accessibility");
            dumpVisibleText();
            return;
        }
        handler.postDelayed(() -> {
            if (!canContinue()) return;
            boolean ok = clickAny(new String[]{"Auto captions", "Auto Captions", "Auto caption", "Recognise speech", "Recognize speech"});
            if (ok) handler.postDelayed(this::generateStage, 700);
            else retryOpenAutoCaptions(attempt + 1);
        }, 650);
    }

    private void generateStage() {
        if (!canContinue()) return;
        emit("3/5 Starting Auto Captions…");

        // CapCut versions differ: some auto-start when entering Auto Captions, others show Generate/Create.
        boolean started = clickAny(new String[]{"Generate", "Create", "Start", "Continue", "Recognize", "Recognise", "Create captions"});
        if (!started) {
            // If source selector is present, prefer original sound / video.
            clickAny(new String[]{"Original sound", "From video", "Video", "Sound from video"});
            handler.postDelayed(() -> clickAny(new String[]{"Generate", "Create", "Start", "Continue", "Recognize", "Recognise"}), 550);
        }

        emit("Auto Captions running • waiting for CapCut…");
        waitForCaptionGeneration(0);
    }

    private void waitForCaptionGeneration(int tick) {
        if (!canContinue()) return;
        boolean busy = hasAnyText(new String[]{"Generating", "Recognizing", "Recognising", "Processing", "Creating captions"});
        boolean doneSignal = hasAnyText(new String[]{"Batch edit", "Edit captions", "Caption style", "Style"});

        if (doneSignal || (!busy && tick >= 8) || tick >= 35) {
            handler.postDelayed(this::captionEditStage, 600);
            return;
        }
        emit("Auto Captions • " + Math.min(95, 10 + tick * 3) + "%");
        handler.postDelayed(() -> waitForCaptionGeneration(tick + 1), 900);
    }

    private void captionEditStage() {
        if (!canContinue()) return;
        emit("4/5 Reading captions + analyzing visuals…");
        captureVisual(() -> {
            if (!canContinue()) return;
            boolean batch = clickAny(new String[]{"Batch edit", "Batch Edit", "Edit captions", "Caption editing"});
            handler.postDelayed(() -> processVisibleCaptionPage(0, batch ? 0 : 1), batch ? 700 : 250);
        });
    }

    private void processVisibleCaptionPage(int page, int noBatchMode) {
        if (!canContinue()) return;
        if (page >= 12) {
            finishSuccess();
            return;
        }

        List<CaptionNode> nodes = collectCaptionNodes();
        List<CaptionNode> fresh = new ArrayList<>();
        for (CaptionNode c : nodes) {
            String key = c.text.toLowerCase(Locale.US).trim();
            if (!seenCaptions.contains(key)) {
                seenCaptions.add(key);
                fresh.add(c);
            }
        }

        if (fresh.isEmpty()) {
            // Try timeline/list scrolling. If scrolling stops, finish.
            if (!scrollForward()) {
                if (styledCount == 0 && noBatchMode == 1) {
                    emit("Captions generated. I cannot read individual caption rows on this CapCut build yet.");
                    AutomationLog.add(this, "No accessible individual caption rows");
                }
                finishSuccess();
            } else {
                handler.postDelayed(() -> processVisibleCaptionPage(page + 1, noBatchMode), 550);
            }
            return;
        }

        processCaptionList(fresh, 0, () -> {
            if (!canContinue()) return;
            boolean scrolled = scrollForward();
            handler.postDelayed(() -> {
                if (scrolled) processVisibleCaptionPage(page + 1, noBatchMode);
                else finishSuccess();
            }, 500);
        });
    }

    private void processCaptionList(List<CaptionNode> list, int index, Runnable done) {
        if (!canContinue()) return;
        if (index >= list.size()) { done.run(); return; }

        CaptionNode c = list.get(index);
        emit("Styling caption " + (styledCount + 1) + " • “" + shorten(c.text, 28) + "”");

        if (!clickNodeOrParent(c.node)) {
            handler.postDelayed(() -> processCaptionList(list, index + 1, done), 120);
            return;
        }

        handler.postDelayed(() -> {
            if (!canContinue()) return;
            captureVisual(() -> {
                ReferenceCaptionBrain.Decision d = ReferenceCaptionBrain.decide(c.text, lastVisual);
                applyDecision(d, () -> {
                    styledCount++;
                    handler.postDelayed(() -> processCaptionList(list, index + 1, done), 220);
                });
            });
        }, 300);
    }

    private void applyDecision(ReferenceCaptionBrain.Decision d, Runnable done) {
        if (!canContinue()) return;
        AutomationLog.add(this, "Decision: " + d.style + " / " + d.position + " / " + d.colorName + " / " + d.motion);

        boolean styleOpened = clickAny(new String[]{"Style", "Text style", "Styles"});
        handler.postDelayed(() -> {
            if (!canContinue()) return;
            if (styleOpened) {
                // Font family hints from the references. These are semantic candidates because CapCut font packs vary.
                clickAny(new String[]{"Font"});
                if (d.fontHint.contains("serif")) clickAny(new String[]{"Serif", "Classic", "Times"});
                else if (d.fontHint.contains("extra-bold")) clickAny(new String[]{"Bold", "Heavy", "Impact"});
                else clickAny(new String[]{"System", "Sans", "Bold"});

                // Color selection if CapCut exposes color names/content descriptions.
                clickAny(new String[]{"Color", "Text color"});
                if ("yellow".equals(d.colorName)) clickAny(new String[]{"Yellow"});
                else if ("red".equals(d.colorName)) clickAny(new String[]{"Red", "Dark red"});
                else if ("black".equals(d.colorName)) clickAny(new String[]{"Black"});
                else clickAny(new String[]{"White"});

                if (d.outline) {
                    clickAny(new String[]{"Stroke", "Outline"});
                }
            }

            // Selective motion only; references do not animate every word.
            if (!"none".equals(d.motion)) {
                clickAny(new String[]{"Animation", "Animations"});
                handler.postDelayed(() -> {
                    if ("soft-fade".equals(d.motion)) clickAny(new String[]{"Fade", "Fade in"});
                    else clickAny(new String[]{"Pop", "Pop up", "Bounce", "Zoom"});
                    moveSelectedCaptionTo(d.position);
                    done.run();
                }, 160);
            } else {
                moveSelectedCaptionTo(d.position);
                done.run();
            }
        }, 220);
    }

    private void moveSelectedCaptionTo(String zone) {
        // Drag the selected caption from CapCut's typical default lower-center preview location
        // into the least-busy safe zone found by VisualBrain. Coordinates are normalized.
        float tx=.50f, ty=.48f;
        if (zone.contains("left")) tx=.28f;
        else if (zone.contains("right")) tx=.72f;
        if (zone.startsWith("top")) ty=.27f;
        else if (zone.startsWith("mid")) ty=.40f;
        else ty=.51f;
        dragNormalized(.50f, .50f, tx, ty, 260);
    }

    private void finishSuccess() {
        if (stopped) return;
        running = false;
        if (styledCount > 0) emit("DONE • styled " + styledCount + " captions with the 5-video brain");
        else emit("DONE • Auto Captions created; no editable caption rows were exposed by this CapCut build");
        AutomationLog.add(this, "Finished. Styled=" + styledCount);
    }

    private void resumeFromCurrentScreen() {
        if (!running || stopped) return;
        if (!isCapCutForeground()) { emit("Return to CapCut to resume"); return; }
        captionEditStage();
    }

    private boolean canContinue() {
        if (stopped) return false;
        if (paused) { emit("Paused"); return false; }
        if (!isCapCutForeground()) {
            emit("CapCut is not foreground • return to the project");
            return false;
        }
        return true;
    }

    private void captureVisual(Runnable after) {
        if (Build.VERSION.SDK_INT < 30) {
            lastVisual = null;
            after.run();
            return;
        }
        try {
            Executor executor = command -> handler.post(command);
            takeScreenshot(0, executor, new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult result) {
                    try {
                        HardwareBuffer hb = result.getHardwareBuffer();
                        ColorSpace cs = result.getColorSpace();
                        Bitmap hardware = Bitmap.wrapHardwareBuffer(hb, cs);
                        if (hardware != null) {
                            Bitmap bmp = hardware.copy(Bitmap.Config.ARGB_8888, false);
                            lastVisual = VisualBrain.analyze(bmp);
                            AutomationLog.add(CapCutAccessibilityService.this,
                                    "Visual brightness=" + lastVisual.brightness + " edge=" + lastVisual.edgeDensity + " safe=" + lastVisual.safestZone);
                            bmp.recycle();
                        }
                        hb.close();
                    } catch (Throwable t) {
                        AutomationLog.add(CapCutAccessibilityService.this, "Screenshot analyze error: " + t);
                    }
                    after.run();
                }
                @Override public void onFailure(int errorCode) {
                    AutomationLog.add(CapCutAccessibilityService.this, "Screenshot failed=" + errorCode);
                    after.run();
                }
            });
        } catch (Throwable t) {
            AutomationLog.add(this, "takeScreenshot unavailable: " + t);
            after.run();
        }
    }

    private boolean isCapCutForeground() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null) return false;
        String p = root.getPackageName().toString();
        for (String pkg : CAPCUT_PACKAGES) if (pkg.equals(p)) return true;
        return false;
    }

    private boolean clickAny(String[] candidates) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        for (String c : candidates) {
            AccessibilityNodeInfo n = findByText(root, c.toLowerCase(Locale.US));
            if (n != null && clickNodeOrParent(n)) {
                AutomationLog.add(this, "Clicked label: " + c);
                return true;
            }
        }
        return false;
    }

    private boolean hasAnyText(String[] candidates) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        for (String c : candidates) if (findByText(root, c.toLowerCase(Locale.US)) != null) return true;
        return false;
    }

    private AccessibilityNodeInfo findByText(AccessibilityNodeInfo node, String needle) {
        if (node == null) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if (t != null && t.toString().toLowerCase(Locale.US).contains(needle)) return node;
        if (d != null && d.toString().toLowerCase(Locale.US).contains(needle)) return node;
        for (int i=0;i<node.getChildCount();i++) {
            AccessibilityNodeInfo out = findByText(node.getChild(i), needle);
            if (out != null) return out;
        }
        return null;
    }

    private boolean clickNodeOrParent(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i=0;i<6 && cur!=null;i++) {
            if (cur.isClickable() && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            cur = cur.getParent();
        }
        return n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private List<CaptionNode> collectCaptionNodes() {
        List<CaptionNode> out = new ArrayList<>();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        collectTextNodes(root, out);
        return out;
    }

    private void collectTextNodes(AccessibilityNodeInfo n, List<CaptionNode> out) {
        if (n == null) return;
        CharSequence cs = n.getText();
        if (cs != null) {
            String s = cs.toString().trim();
            if (looksLikeCaption(s, n)) out.add(new CaptionNode(s, n));
        }
        for (int i=0;i<n.getChildCount();i++) collectTextNodes(n.getChild(i), out);
    }

    private boolean looksLikeCaption(String s, AccessibilityNodeInfo n) {
        if (s.length() < 2 || s.length() > 90) return false;
        String l = s.toLowerCase(Locale.US);
        String[] ui = {"caption","captions","style","font","animation","delete","split","edit","batch edit","effects","overlay","audio","text","export","undo","redo","generate","create","start","cancel","done","save","original sound","from video","video","language","bilingual"};
        for (String x: ui) if (l.equals(x) || l.startsWith(x + " ")) return false;
        int words = s.split("\\s+").length;
        if (words > 16) return false;
        String clazz = String.valueOf(n.getClassName());
        return clazz.contains("Text") || n.isClickable();
    }

    private boolean scrollForward() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo scroll = findScrollable(root);
        if (scroll != null && scroll.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
            AutomationLog.add(this, "Scrolled caption list forward");
            return true;
        }
        return false;
    }

    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n) {
        if (n == null) return null;
        if (n.isScrollable()) return n;
        for (int i=0;i<n.getChildCount();i++) {
            AccessibilityNodeInfo x = findScrollable(n.getChild(i));
            if (x != null) return x;
        }
        return null;
    }

    private void dumpVisibleText() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        List<String> list = new ArrayList<>();
        collectAllText(root, list);
        AutomationLog.add(this, "Visible UI: " + list.toString());
    }

    private void collectAllText(AccessibilityNodeInfo n, List<String> out) {
        if (n == null) return;
        if (n.getText() != null) out.add(n.getText().toString());
        if (n.getContentDescription() != null) out.add("[" + n.getContentDescription() + "]");
        for (int i=0;i<n.getChildCount();i++) collectAllText(n.getChild(i), out);
    }

    private void tapNormalized(float x, float y) {
        if (Build.VERSION.SDK_INT < 24) return;
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        Path p = new Path(); p.moveTo(w*x, h*y);
        GestureDescription g = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,70)).build();
        dispatchGesture(g, null, null);
    }

    private void dragNormalized(float x1, float y1, float x2, float y2, long duration) {
        if (Build.VERSION.SDK_INT < 24) return;
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        Path p = new Path(); p.moveTo(w*x1,h*y1); p.lineTo(w*x2,h*y2);
        GestureDescription g = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,duration)).build();
        dispatchGesture(g, null, null);
    }

    private void emit(String s) {
        AutomationLog.add(this, s);
        if (callback != null) callback.onStatus(s);
    }

    private static String shorten(String s, int n) { return s.length() <= n ? s : s.substring(0,n-1) + "…"; }

    private static final class CaptionNode {
        final String text;
        final AccessibilityNodeInfo node;
        CaptionNode(String text, AccessibilityNodeInfo node) { this.text=text; this.node=node; }
    }

    public interface StatusCallback { void onStatus(String status); }
}
