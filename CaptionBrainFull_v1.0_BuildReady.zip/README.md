# CaptionBrain Mobile v1.0 — Full Caption Beta

Caption-only CapCut assistant. This build does not try to edit the whole video. The user opens an existing CapCut project, taps the floating CB button, then START AI CAPTIONS.

## Intended flow
1. Verify CapCut project is foreground.
2. Analyze the current visible video frame.
3. Open CapCut Captions / Auto Captions and generate captions from the project voiceover.
4. Read accessible caption rows.
5. For each caption, combine caption semantics + current-frame visual complexity.
6. Choose a caption treatment distilled from the five supplied reference videos.
7. Apply font-family hints, color, emphasis, selective motion, and move the caption toward the least-busy safe zone.

## Five supplied reference videos used for the caption brain
- 30 Uncomfortable Things to Do Alone (Build Confidence)
- What To Do When Your Mind Won't Shut Up
- You're too humble to succeed
- how to force creativity
- How to Ruin Your 20s in 100 Seconds

## Reference caption families
- Bold white sans over live footage
- Small yellow cinematic support lines
- Black editorial type on clean/light frames
- Red/dark-red serif accents on reflective clean frames
- White serif emotional lines over cinematic footage
- Oversized short punch-word treatment
- Dynamic placement toward the least-busy visual zone
- Selective motion/keyframing rather than animating every caption

## Technical boundary
CapCut changes UI structure, labels, fonts, and accessibility exposure across versions and regions. CaptionBrain therefore searches semantic UI labels first, verifies CapCut is foreground, uses normalized gestures only as fallbacks, and may need per-version adaptation where CapCut hides individual caption rows or style controls from Android Accessibility.
